# StudyLink - Improved Peer Tutoring System

An improved, modular version of the StudyLink prototype for Caraga State University students with fixed authentication, functional tutor search, and removed FR/NFR references.

## Key Improvements

### ✅ Fixed Authentication System
- **Mock user database** with 6 test accounts (5 students, 1 admin)
- **Proper login validation** - rejects invalid credentials with clear error messages
- **Registration with validation** - checks required fields, email format, password length
- **Session persistence** via localStorage
- **Auth guards** on all protected pages
- **Functional logout** that clears session and redirects to login
- **Role-based access** (student, tutor, admin) ready for future expansion

### ✅ Fully Functional Find Tutor
- **Dynamic tutor data** loaded from separate data file (5 tutors with rich profiles)
- **Search by subject** with dynamically populated dropdown
- **Filters**: Expertise level, Availability (morning/afternoon/evening), Minimum rating
- **Combined search + filters** work together
- **No results handling** with helpful message and "Change Filters" button
- **Correct tutor profile navigation** - each tutor card opens their actual profile

### ✅ Removed FR/NFR References
- All `srs-tag` elements (FR-01, FR-02, etc.) removed from UI
- Clean, student-facing interface without requirement documentation
- All functionality preserved

### ✅ Complete Request Flow
- **4-step wizard**: Date → Time → Details → Confirm
- **Tutor availability** drives available dates/times
- **Subject selection** from tutor's actual subjects + custom option
- **Confirmation screen** shows all details correctly
- **Request tracking** in My Requests with status management

### ✅ My Requests Management
- **Student view**: See sent requests, cancel pending ones with reasons
- **Tutor view**: See received requests, accept/decline with reasons
- **Modal dialogs** for cancellation/decline reasons
- **Request details modal** with full information

## Project Structure

```
studylink-modular/
├── index.html              # Main HTML with all 9 screens
├── README.md               # This file
├── css/
│   ├── global.css          # Design tokens, base styles, shared components
│   ├── login.css           # Login/Register page styles
│   ├── dashboard.css       # Dashboard page styles
│   ├── search.css          # Search & Results page styles
│   ├── profile.css         # Tutor Profile page styles
│   ├── request.css         # Request Session Flow page styles
│   ├── confirmation.css    # Confirmation page styles
│   └── my-requests.css     # My Requests page styles
├── js/
│   ├── app.js              # Main application entry point
│   ├── state.js            # Shared application state (AppState singleton)
│   ├── navigation.js       # Screen navigation, history, auth guards
│   ├── utils.js            # Utility functions (date/time formatting, etc.)
│   ├── tutors.js           # Tutor data access & filtering
│   └── pages/              # Page-specific logic (9 modules)
│       ├── login.js
│       ├── register.js
│       ├── dashboard.js
│       ├── search.js
│       ├── search-results.js
│       ├── profile.js
│       ├── request-flow.js
│       ├── confirmation.js
│       └── my-requests.js
├── data/
│   ├── users.js            # Mock user accounts (6 test users)
│   └── tutors.js           # Mock tutor profiles (5 tutors)
└── assets/                 # Images and other assets (if any)
```

## Test Accounts

| Email | Password | Role | Notes |
|-------|----------|------|-------|
| maria.santos@csu.edu.ph | password123 | Student | Not a tutor |
| juan.delacruz@csu.edu.ph | password123 | Student | Also a tutor (Programming) |
| anna.rodriguez@csu.edu.ph | password123 | Student | Also a tutor (English) |
| pedro.garcia@csu.edu.ph | password123 | Student | Not a tutor |
| lisa.fernandez@csu.edu.ph | password123 | Student | Also a tutor (Physics) |
| admin@csu.edu.ph | admin123 | Admin | System administrator |

## How to Run

### Option 1: VS Code Live Server (Recommended)
1. Open the `studylink-modular` folder in VS Code
2. Install the "Live Server" extension if not already installed
3. Right-click `index.html` and select "Open with Live Server"
4. The app will open in your default browser

### Option 2: Python HTTP Server
```bash
cd studylink-modular
python -m http.server 8000
```
Then open `http://localhost:8000` in your browser.

### Option 3: Node.js http-server
```bash
cd studylink-modular
npx http-server
```
Then open the provided URL in your browser.

### Option 4: Direct File Open
Simply double-click `index.html` to open it directly in your browser.
*Note: Some features may be limited due to CORS restrictions when opening files directly.*

## Application Flow

1. **Login/Register** → Enter CSU email to access the system
2. **Dashboard** → Choose "Find a Tutor" or "My Requests"
3. **Find Tutor** → Set search filters (subject, expertise, availability, rating)
4. **Search Results** → View matching tutors, click "View Profile"
5. **Tutor Profile** → Review tutor details, click "Request Tutoring Session"
6. **Request Session** → 4-step flow:
   - Step 1: Select Date (based on tutor availability)
   - Step 2: Select Time (30-min slots)
   - Step 3: Session Details (subject, notes)
   - Step 4: Confirm & Submit
7. **Confirmation** → Request sent, view status in "My Requests"
8. **My Requests** → View all requests, cancel (student) or accept/decline (tutor)

## Key Design Decisions

### Modular Architecture
- Each page has its own JavaScript module in `js/pages/`
- Shared state managed through `AppState` singleton
- Navigation handled by `Navigation` module with auth guards
- Tutor data accessed through `Tutors` module
- Utilities in `Utils` module

### CSS Organization
- `global.css` contains all design tokens, base styles, and shared components
- Page-specific CSS files only contain overrides or unique styles
- CSS custom properties (variables) for theming
- Dark mode via `prefers-color-scheme` media query

### State Management
- `AppState` persists to `localStorage` for session persistence
- Navigation history enables back button functionality
- Request flow state managed separately for multi-step wizard
- Search/filter state preserved between navigation

### Data Structure (Ready for Backend Integration)
```
users.js → Mock user accounts with roles
tutors.js → Tutor profiles linked to users via userId
```
Both files are structured to easily map to database tables:
- `users` table: id, email, password_hash, full_name, course, year_level, role, is_tutor
- `tutors` table: id, user_id (FK), subjects, expertise, availability, rating, bio, etc.

## Browser Support

- Chrome/Edge 88+
- Firefox 78+
- Safari 14+
- Mobile browsers (iOS Safari, Chrome for Android)

## Customization

### Adding New Tutors
Edit `data/tutors.js` and add new tutor objects following the existing structure.

### Adding New Users
Edit `data/users.js` and add new user objects. Passwords should be hashed in production.

### Modifying Styles
- Design tokens in `css/global.css` `:root` section
- Page-specific styles in respective CSS files
- Dark mode tokens in `@media (prefers-color-scheme: dark)` block

### Extending Functionality
- Add new pages by creating HTML sections in `index.html`
- Create corresponding CSS in `css/` and JS in `js/pages/`
- Register screen show handlers using `document.addEventListener('screen:show', ...)`

## Security Notes (Important)

⚠️ **This is a prototype with temporary mock authentication.**

**Current limitations (to be fixed for production):**
- Passwords stored in plain text in mock data
- No password hashing (bcrypt/Argon2)
- No CSRF protection
- No rate limiting on login attempts
- No secure session cookies
- Client-side only validation

**For production deployment:**
1. Move authentication to PHP backend with MySQL
2. Use `password_hash()` and `password_verify()` in PHP
3. Implement prepared statements for all database queries
4. Add HTTPS, secure cookies, CSRF tokens
5. Implement proper session management
6. Add input sanitization and validation on server side

## License

Prototype for educational purposes - Caraga State University