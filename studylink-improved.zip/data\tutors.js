/**
 * StudyLink - Mock Tutor Data
 * Temporary mock data for tutor profiles (to be replaced with PHP/MySQL backend)
 *
 * IMPORTANT: This is temporary mock data for prototyping only.
 * In production, this data would come from a database with proper relationships to users.
 */

const tutors = {
    maria: {
        id: 'maria',
        userId: 'user_002', // Links to Juan dela Cruz (who is a tutor)
        name: 'Maria Santos',
        initials: 'MS',
        email: 'maria.santos.tutor@csu.edu.ph',
        profileImage: null, // Could be a URL to an image
        subjects: ['Mathematics', 'Calculus', 'Algebra', 'Statistics'],
        expertise: 'Intermediate to Advanced Level',
        availability: 'Mondays, Wednesdays, Fridays (3:00 PM - 6:00 PM)',
        availabilityDays: [1, 3, 5], // Monday, Wednesday, Friday
        availabilityStart: 15 * 60, // 15:00 in minutes
        availabilityEnd: 18 * 60,   // 18:00 in minutes
        rating: 4.8,
        reviewCount: 24,
        bio: 'Experienced math tutor with 3 years of teaching experience. Specializes in helping students understand complex mathematical concepts through practical examples. Currently a 3rd year BS Mathematics student with consistent Dean\'s List standing.',
        topics: ['Quadratic Equations', 'Trigonometry', 'Calculus Fundamentals', 'Probability', 'Linear Algebra'],
        reviews: [
            { author: 'Pedro G.', rating: 5, comment: 'Maria helped me improve my math grade from C to A in just one semester!', date: '2024-02-15' },
            { author: 'Lisa F.', rating: 5, comment: 'Very patient and explains concepts clearly. Highly recommend!', date: '2024-02-10' },
            { author: 'Mark R.', rating: 4, comment: 'Great tutor, knows the material well.', date: '2024-01-28' }
        ],
        course: 'BS Mathematics',
        yearLevel: 3,
        isVerified: true,
        joinedAt: '2024-01-15'
    },
    juan: {
        id: 'juan',
        userId: 'user_002', // Links to Juan dela Cruz
        name: 'Juan dela Cruz',
        initials: 'JdC',
        email: 'juan.delacruz.tutor@csu.edu.ph',
        profileImage: null,
        subjects: ['Programming', 'Java Programming', 'Data Structures and Algorithms', 'Python', 'Web Development'],
        expertise: 'Beginner to Intermediate Level',
        availability: 'Tuesdays, Thursdays (4:00 PM - 7:00 PM)',
        availabilityDays: [2, 4], // Tuesday, Thursday
        availabilityStart: 16 * 60, // 16:00
        availabilityEnd: 19 * 60,   // 19:00
        rating: 4.5,
        reviewCount: 18,
        bio: 'Computer Science senior with experience in Java, Python, and web development. Helps students with coding assignments, programming concepts, and project guidance. Passionate about making programming accessible to everyone.',
        topics: ['Object-Oriented Programming', 'Algorithms', 'Web Development Basics', 'Database Fundamentals', 'Version Control (Git)'],
        reviews: [
            { author: 'Maria S.', rating: 5, comment: 'Juan helped me debug my final project and get it working!', date: '2024-02-20' },
            { author: 'Anna R.', rating: 4, comment: 'Great tutor for programming beginners. Very knowledgeable.', date: '2024-02-05' },
            { author: 'Pedro G.', rating: 5, comment: 'Excellent at explaining data structures.', date: '2024-01-30' }
        ],
        course: 'BS Computer Science',
        yearLevel: 4,
        isVerified: true,
        joinedAt: '2024-01-10'
    },
    anna: {
        id: 'anna',
        userId: 'user_003', // Links to Anna Rodriguez
        name: 'Anna Rodriguez',
        initials: 'AR',
        email: 'anna.rodriguez.tutor@csu.edu.ph',
        profileImage: null,
        subjects: ['English', 'Literature', 'Writing', 'Communication', 'Public Speaking', 'Academic Writing'],
        expertise: 'All Levels',
        availability: 'Weekends (9:00 AM - 12:00 PM)',
        availabilityDays: [0, 6], // Saturday, Sunday
        availabilityStart: 9 * 60,  // 09:00
        availabilityEnd: 12 * 60,   // 12:00
        rating: 4.7,
        reviewCount: 31,
        bio: 'English Literature graduate passionate about helping students improve their writing and communication skills. Specializes in academic writing, literary analysis, and public speaking. Published author in university literary journal.',
        topics: ['Essay Writing', 'Literary Analysis', 'Public Speaking', 'Creative Writing', 'Research Writing', 'Grammar & Style'],
        reviews: [
            { author: 'Maria S.', rating: 5, comment: 'Anna helped me improve my essay writing skills significantly.', date: '2024-02-18' },
            { author: 'Juan D.', rating: 5, comment: 'Very encouraging and helpful with literature assignments.', date: '2024-02-12' },
            { author: 'Lisa F.', rating: 4, comment: 'Great feedback on my research paper.', date: '2024-01-25' }
        ],
        course: 'BA English Language Studies',
        yearLevel: 3,
        isVerified: true,
        joinedAt: '2024-02-01'
    },
    lisa: {
        id: 'lisa',
        userId: 'user_005', // Links to Lisa Fernandez
        name: 'Lisa Fernandez',
        initials: 'LF',
        email: 'lisa.fernandez.tutor@csu.edu.ph',
        profileImage: null,
        subjects: ['Physics', 'General Physics', 'Mechanics', 'Thermodynamics', 'Electromagnetism'],
        expertise: 'Advanced Level',
        availability: 'Mondays, Thursdays (5:00 PM - 8:00 PM)',
        availabilityDays: [1, 4], // Monday, Thursday
        availabilityStart: 17 * 60, // 17:00
        availabilityEnd: 20 * 60,   // 20:00
        rating: 4.9,
        reviewCount: 15,
        bio: 'Physics major with strong academic background. Excels at breaking down complex physics concepts into understandable parts. Has tutored over 30 students in various physics topics.',
        topics: ['Newtonian Mechanics', 'Thermodynamics', 'Electromagnetism', 'Wave Optics', 'Modern Physics'],
        reviews: [
            { author: 'Pedro G.', rating: 5, comment: 'Lisa made physics finally click for me!', date: '2024-02-22' },
            { author: 'Mark R.', rating: 5, comment: 'Best physics tutor I\'ve had. Very clear explanations.', date: '2024-02-08' }
        ],
        course: 'BS Physics',
        yearLevel: 4,
        isVerified: true,
        joinedAt: '2024-01-05'
    }
};

// Export for module usage
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { tutors };
}

// Make available globally
window.TutorsData = tutors;