/**
 * StudyLink - Mock User Data
 * Temporary mock data for authentication (to be replaced with PHP/MySQL backend)
 *
 * IMPORTANT: This is temporary mock data for prototyping only.
 * Do not use in production. Passwords are stored in plain text for demo purposes only.
 * In production, use proper password hashing (bcrypt, Argon2) and secure authentication.
 */

const mockUsers = [
    {
        id: 'user_001',
        email: 'maria.santos@csu.edu.ph',
        password: 'password123',
        fullName: 'Maria Santos',
        course: 'BS Computer Science',
        yearLevel: 3,
        role: 'student',
        isTutor: false,
        createdAt: '2024-01-15T08:30:00Z'
    },
    {
        id: 'user_002',
        email: 'juan.delacruz@csu.edu.ph',
        password: 'password123',
        fullName: 'Juan dela Cruz',
        course: 'BS Information Technology',
        yearLevel: 4,
        role: 'student',
        isTutor: true,
        createdAt: '2024-01-10T10:15:00Z'
    },
    {
        id: 'user_003',
        email: 'anna.rodriguez@csu.edu.ph',
        password: 'password123',
        fullName: 'Anna Rodriguez',
        course: 'BA English Language Studies',
        yearLevel: 3,
        role: 'student',
        isTutor: true,
        createdAt: '2024-02-01T14:20:00Z'
    },
    {
        id: 'user_004',
        email: 'pedro.garcia@csu.edu.ph',
        password: 'password123',
        fullName: 'Pedro Garcia',
        course: 'BS Mathematics',
        yearLevel: 2,
        role: 'student',
        isTutor: false,
        createdAt: '2024-02-20T09:45:00Z'
    },
    {
        id: 'user_005',
        email: 'lisa.fernandez@csu.edu.ph',
        password: 'password123',
        fullName: 'Lisa Fernandez',
        course: 'BS Computer Science',
        yearLevel: 4,
        role: 'student',
        isTutor: true,
        createdAt: '2024-01-05T11:00:00Z'
    },
    {
        id: 'user_006',
        email: 'admin@csu.edu.ph',
        password: 'admin123',
        fullName: 'System Administrator',
        course: 'Administration',
        yearLevel: 0,
        role: 'admin',
        isTutor: false,
        createdAt: '2023-12-01T08:00:00Z'
    }
];

// Export for module usage
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { mockUsers };
}

// Make available globally
window.MockUsers = mockUsers;