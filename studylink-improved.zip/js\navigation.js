/**
 * StudyLink - Navigation Module
 * Handles screen transitions, history management, and top bar visibility
 */

const Navigation = {
    // Current active screen
    currentScreen: null,

    // Screen element cache
    screenCache: {},

    // Protected screens that require authentication
    protectedScreens: [
        'dashboard-screen',
        'tutor-search-screen',
        'search-results-screen',
        'tutor-profile-screen',
        'request-session-flow-screen',
        'confirmation-screen',
        'my-requests-screen'
    ],

    /**
     * Show a specific screen by ID
     * @param {string} screenId - The ID of the screen element to show
     */
    showScreen(screenId) {
        // Check authentication for protected screens
        if (this.protectedScreens.includes(screenId) && !AppState.isAuthenticated()) {
            // Redirect to login with a message
            this.showLoginWithMessage('Please log in to access this page.');
            return;
        }

        // Hide all screens
        document.querySelectorAll('.screen, [id$="-screen"]').forEach(el => {
            el.classList.remove('active');
        });

        // Get and show target screen
        const screen = this.getScreen(screenId);
        if (screen) {
            screen.classList.add('active');

            // Ensure screen class is present
            if (!screen.classList.contains('screen')) {
                screen.classList.add('screen');
            }

            // Update navigation history
            AppState.pushHistory(screenId);

            // Focus the main heading for accessibility
            const heading = screen.querySelector('h1, h2');
            if (heading) {
                heading.focus({ preventScroll: true });
            }

            // Update top bar visibility
            this.updateTopBar();

            // Update progress strip
            this.updateProgressStrip();

            // Call screen-specific onShow handlers
            this.triggerScreenShow(screenId);

            this.currentScreen = screenId;
        }
    },

    /**
     * Show login screen with a message
     * @param {string} message - Message to display
     */
    showLoginWithMessage(message) {
        // Show login screen
        document.querySelectorAll('.screen, [id$="-screen"]').forEach(el => {
            el.classList.remove('active');
        });
        const loginScreen = this.getScreen('login-screen');
        if (loginScreen) {
            loginScreen.classList.add('active');
        }

        // Show message on login form
        const errorEl = document.getElementById('login-email-error');
        if (errorEl && message) {
            errorEl.textContent = message;
            errorEl.style.color = 'var(--error-color)';
        }

        // Update top bar
        this.updateTopBar();
        this.updateProgressStrip();
        this.currentScreen = 'login-screen';
    },

    /**
     * Get screen element, with caching
     * @param {string} screenId
     * @returns {HTMLElement|null}
     */
    getScreen(screenId) {
        if (!this.screenCache[screenId]) {
            this.screenCache[screenId] = document.getElementById(screenId);
        }
        return this.screenCache[screenId];
    },

    /**
     * Go back to previous screen in history
     */
    goBack() {
        const previousScreen = AppState.popHistory();
        this.showScreen(previousScreen);
    },

    /**
     * Clear navigation history
     */
    clearHistory() {
        AppState.clearHistory();
    },

    /**
     * Update top bar visibility based on navigation state
     */
    updateTopBar() {
        const topBar = document.getElementById('top-bar');
        if (topBar) {
            topBar.classList.toggle('active', AppState.navigationHistory.length > 0);
        }
    },

    /**
     * Update progress strip active step
     */
    updateProgressStrip() {
        const steps = [
            { id: 'login-screen', label: '1. Login' },
            { id: 'dashboard-screen', label: '2. Dashboard' },
            { id: 'tutor-search-screen', label: '3. Search' },
            { id: 'search-results-screen', label: '4. Results' },
            { id: 'tutor-profile-screen', label: '5. Profile' },
            { id: 'request-session-flow-screen', label: '6. Request' },
            { id: 'confirmation-screen', label: '7. Confirmation' }
        ];

        steps.forEach((step, index) => {
            const element = document.querySelector(`.progress-step[data-step="${index + 1}"]`);
            if (element) {
                const isActive = document.getElementById(step.id)?.classList.contains('active');
                element.classList.toggle('active', isActive);
                element.textContent = step.label;
            }
        });
    },

    /**
     * Trigger screen-specific show events
     * @param {string} screenId
     */
    triggerScreenShow(screenId) {
        // Dispatch custom event for screen-specific initialization
        const event = new CustomEvent('screen:show', {
            detail: { screenId }
        });
        document.dispatchEvent(event);
    },

    /**
     * Initialize progress strip in DOM
     */
    initProgressStrip() {
        // Check if already exists
        if (document.querySelector('.progress-strip')) {
            return;
        }

        const progressStrip = document.createElement('div');
        progressStrip.className = 'progress-strip';

        for (let i = 1; i <= 7; i++) {
            const step = document.createElement('div');
            step.className = 'progress-step';
            step.dataset.step = i;
            progressStrip.appendChild(step);
        }

        const container = document.querySelector('.container');
        const topBar = document.getElementById('top-bar');

        if (container && topBar) {
            container.insertBefore(progressStrip, topBar.nextSibling);
        }
    }
};

// Export for module usage
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { Navigation };
}

// Make available globally
window.Navigation = Navigation;