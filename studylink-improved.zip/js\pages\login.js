/**
 * StudyLink - Login Page Logic
 * Handles user authentication with mock user data
 */

const LoginPage = {
    /**
     * Initialize login page
     */
    init() {
        this.bindEvents();
        this.checkRedirect();
    },

    /**
     * Check if user should be redirected (already logged in)
     */
    checkRedirect() {
        if (AppState.currentUser.isLoggedIn) {
            Navigation.showScreen('dashboard-screen');
        }
    },

    /**
     * Bind event listeners
     */
    bindEvents() {
        // Login form submission
        const loginForm = document.getElementById('login-form');
        if (loginForm) {
            loginForm.addEventListener('submit', (e) => this.handleLogin(e));
        }

        // Register link
        const registerLink = document.getElementById('show-register-link');
        if (registerLink) {
            registerLink.addEventListener('click', (e) => {
                e.preventDefault();
                Navigation.showScreen('register-screen');
            });
        }

        // Clear error on input
        const emailInput = document.getElementById('login-email');
        const passwordInput = document.getElementById('login-password');
        if (emailInput) {
            emailInput.addEventListener('input', () => Utils.clearError('login-email-error'));
        }
        if (passwordInput) {
            passwordInput.addEventListener('input', () => Utils.clearError('login-email-error'));
        }
    },

    /**
     * Handle login form submission
     * @param {Event} e - Submit event
     */
    handleLogin(e) {
        e.preventDefault();

        const emailInput = document.getElementById('login-email');
        const passwordInput = document.getElementById('login-password');
        const email = emailInput.value.trim();
        const password = passwordInput.value;

        // Validate required fields
        if (!email) {
            Utils.showError('login-email-error', 'Please enter your CSU email address.');
            emailInput.focus();
            return;
        }

        if (!password) {
            Utils.showError('login-email-error', 'Please enter your password.');
            passwordInput.focus();
            return;
        }

        // Validate email format
        if (!Utils.validateEmail(email)) {
            Utils.showError('login-email-error', 'Please enter a valid CSU email address (e.g., student@csu.edu.ph).');
            emailInput.focus();
            return;
        }

        Utils.clearError('login-email-error');

        // Show loading state
        const loginBtn = document.getElementById('login-btn');
        const originalBtnText = loginBtn.textContent;
        loginBtn.textContent = 'Logging in...';
        loginBtn.disabled = true;

        // Simulate async authentication (for future API integration)
        setTimeout(() => {
            // Attempt login using AppState
            const result = AppState.login(email, password);

            if (result.success) {
                // Update dashboard user name
                const userNameEl = document.getElementById('user-name');
                if (userNameEl) {
                    userNameEl.textContent = AppState.currentUser.fullName;
                }

                // Clear form
                document.getElementById('login-form').reset();

                // Navigate to dashboard
                Navigation.showScreen('dashboard-screen');
            } else {
                // Show error
                Utils.showError('login-email-error', result.error);
                emailInput.focus();
            }

            // Restore button
            loginBtn.textContent = originalBtnText;
            loginBtn.disabled = false;
        }, 300); // Small delay for UX
    }
};

// Auto-initialize when login screen is shown
document.addEventListener('screen:show', (e) => {
    if (e.detail.screenId === 'login-screen') {
        LoginPage.init();
    }
});

// Export
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { LoginPage };
}
window.LoginPage = LoginPage;