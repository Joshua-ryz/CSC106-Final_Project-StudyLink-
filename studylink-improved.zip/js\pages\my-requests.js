/**
 * StudyLink - My Requests Page Logic
 * Handles request listing, status updates, and modal interactions
 */

const MyRequestsPage = {
    /**
     * Load and display user's requests
     */
    loadRequests() {
        const content = document.getElementById('my-requests-content');
        const requests = AppState.getUserRequests();

        if (requests.length === 0) {
            content.innerHTML = '<p class="no-results" role="alert">You haven\'t submitted or received any tutoring requests yet.</p>';
            return;
        }

        content.innerHTML = requests.map((req, index) => this.createRequestCard(req, index)).join('');

        // Bind events for dynamically created elements
        this.bindRequestEvents();
    },

    /**
     * Create request card HTML
     * @param {Object} req - Request object
     * @param {number} index - Request index in user's filtered requests
     * @returns {string} HTML string
     */
    createRequestCard(req, index) {
        const currentUserName = AppState.currentUser.fullName;
        const isStudent = req.student === currentUserName;
        const isTutor = req.tutor === currentUserName;
        const formattedDate = Utils.formatDate(req.date);
        const formattedTime = Utils.formatTime(req.time);
        const statusClass = req.status.toLowerCase();

        // Determine available actions based on status and user role
        let actionsHtml = '';
        if (req.status === 'Pending') {
            if (isStudent) {
                actionsHtml = `
                    <div class="request-actions">
                        <button class="button button-secondary" onclick="MyRequestsPage.showCancelReasonForm(${index})">
                            Cancel Request
                        </button>
                    </div>
                `;
            } else if (isTutor) {
                actionsHtml = `
                    <div class="request-actions">
                        <button class="button button-success" onclick="MyRequestsPage.acceptRequest(${index})">
                            Accept Request
                        </button>
                        <button class="button button-error" onclick="MyRequestsPage.showDeclineReasonForm(${index})">
                            Decline Request
                        </button>
                    </div>
                `;
            }
        }

        return `
            <div class="tutor-card" style="border: 2px solid var(--border-color);" data-request-index="${index}">
                <div class="request-header">
                    <h3>Request #${index + 1}</h3>
                    <div class="request-status ${statusClass}">
                        Status: ${req.status.charAt(0).toUpperCase() + req.status.slice(1)}
                    </div>
                </div>

                <div class="request-details">
                    <p><strong>Student:</strong> ${Utils.escapeHtml(req.student)}</p>
                    <p><strong>Tutor:</strong> ${Utils.escapeHtml(req.tutor)}</p>
                    <p><strong>Subject:</strong> ${Utils.escapeHtml(req.subject)}</p>
                    <p><strong>Date:</strong> ${formattedDate}</p>
                    <p><strong>Time:</strong> ${formattedTime}</p>
                    ${req.notes ? `<p><strong>Message:</strong> ${Utils.escapeHtml(req.notes)}</p>` : ''}
                    <p><strong>Submitted:</strong> ${Utils.escapeHtml(req.timestamp)}</p>
                </div>

                ${req.status === 'Cancelled' && req.cancellationReason ? `
                    <div class="cancel-reason">
                        <strong>Cancellation Reason:</strong><br>
                        ${Utils.escapeHtml(req.cancellationReason)}
                    </div>
                ` : ''}

                ${(req.status === 'Declined' || req.status === 'Accepted') && req.declineReason ? `
                    <div class="decline-reason">
                        <strong>Reason:</strong><br>
                        ${Utils.escapeHtml(req.declineReason)}
                    </div>
                ` : ''}

                ${actionsHtml}

                <div class="request-footer">
                    <button class="button button-block" onclick="MyRequestsPage.showRequestDetails(${index})">
                        View Details
                    </button>
                </div>
            </div>
        `;
    },

    /**
     * Bind events for request cards
     */
    bindRequestEvents() {
        // Events are handled via inline onclick for simplicity
        // In a larger app, you'd use event delegation
    },

    // ============ MODAL FUNCTIONS ============

    /**
     * Show cancel reason modal
     * @param {number} requestIndex - Request index in user's filtered requests
     */
    showCancelReasonForm(requestIndex) {
        const userRequests = AppState.getUserRequests();
        const request = userRequests[requestIndex];
        if (!request || request.status !== 'Pending' || request.student !== AppState.currentUser.fullName) {
            return;
        }

        this.createModal({
            title: 'Cancel Tutoring Request',
            message: 'Please select a reason for cancelling this request.',
            formId: 'cancel-reason-form',
            radioName: 'cancelReason',
            options: [
                { value: 'Schedule conflict', label: 'Schedule conflict', checked: true },
                { value: 'I no longer need tutoring', label: 'I no longer need tutoring' },
                { value: 'I found another tutor', label: 'I found another tutor' },
                { value: 'I need to change my preferred date/time', label: 'I need to change my preferred date/time' },
                { value: 'Other', label: 'Other' }
            ],
            otherInputId: 'other-reason',
            confirmText: 'Confirm Cancellation',
            confirmClass: 'button-error',
            onConfirm: () => this.confirmCancelRequest(requestIndex)
        });

        // Bind radio change events
        this.bindRadioToggle('cancelReason', 'other-reason-input');
    },

    /**
     * Show decline reason modal
     * @param {number} requestIndex - Request index in user's filtered requests
     */
    showDeclineReasonForm(requestIndex) {
        const userRequests = AppState.getUserRequests();
        const request = userRequests[requestIndex];
        if (!request || request.status !== 'Pending' || request.tutor !== AppState.currentUser.fullName) {
            return;
        }

        this.createModal({
            title: 'Decline Tutoring Request',
            message: 'Please select a reason for declining this request.',
            formId: 'decline-reason-form',
            radioName: 'declineReason',
            options: [
                { value: 'Not available at the requested time', label: 'Not available at the requested time', checked: true },
                { value: 'Schedule conflict', label: 'Schedule conflict' },
                { value: 'Subject/topic is outside my expertise', label: 'Subject/topic is outside my expertise' },
                { value: 'Unable to accept another session', label: 'Unable to accept another session' },
                { value: 'Other', label: 'Other' }
            ],
            otherInputId: 'declineOtherReason',
            confirmText: 'Confirm Decline',
            confirmClass: 'button-error',
            onConfirm: () => this.confirmDeclineRequest(requestIndex)
        });

        // Bind radio change events
        this.bindRadioToggle('declineReason', 'declineOtherReasonInput');
    },

    /**
     * Show request details modal
     * @param {number} requestIndex - Request index in user's filtered requests
     */
    showRequestDetails(requestIndex) {
        const userRequests = AppState.getUserRequests();
        const request = userRequests[requestIndex];
        if (!request) return;

        this.createModal({
            title: 'Request Details',
            content: `
                <div class="request-details">
                    <p><strong>Student:</strong> ${Utils.escapeHtml(request.student)}</p>
                    <p><strong>Tutor:</strong> ${Utils.escapeHtml(request.tutor)}</p>
                    <p><strong>Subject:</strong> ${Utils.escapeHtml(request.subject)}</p>
                    <p><strong>Date:</strong> ${Utils.formatDate(request.date)}</p>
                    <p><strong>Time:</strong> ${Utils.formatTime(request.time)}</p>
                    ${request.notes ? `<p><strong>Message:</strong> ${Utils.escapeHtml(request.notes)}</p>` : ''}
                    <p><strong>Submitted:</strong> ${Utils.escapeHtml(request.timestamp)}</p>
                    <p><strong>Status:</strong> <span class="request-status ${request.status.toLowerCase()}">${request.status.charAt(0).toUpperCase() + request.status.slice(1)}</span></p>
                    ${request.status === 'Cancelled' && request.cancellationReason ? `
                        <p><strong>Cancellation Reason:</strong><br>${Utils.escapeHtml(request.cancellationReason)}</p>
                    ` : ''}
                    ${(request.status === 'Declined' || request.status === 'Accepted') && request.declineReason ? `
                        <p><strong>Reason:</strong><br>${Utils.escapeHtml(request.declineReason)}</p>
                    ` : ''}
                </div>
            `,
            showCancel: true,
            cancelText: 'Close',
            onCancel: () => this.closeModal()
        });
    },

    /**
     * Create a modal dialog
     * @param {Object} options - Modal options
     */
    createModal(options) {
        // Remove existing modals
        this.closeModal();

        const modal = document.createElement('div');
        modal.className = 'request-modal';

        let formHtml = '';
        if (options.formId) {
            formHtml = `
                <form id="${options.formId}">
                    ${options.options.map((opt, i) => `
                        <div class="reason-option">
                            <input type="radio" id="${options.radioName}${i}" name="${options.radioName}" value="${opt.value}" ${opt.checked ? 'checked' : ''}>
                            <label for="${options.radioName}${i}">${opt.label}</label>
                        </div>
                    `).join('')}
                    <div id="${options.otherInputId}Input" style="margin-top: 10px; display: none;">
                        <label for="${options.otherInputId}">Please specify your reason:</label>
                        <input type="text" id="${options.otherInputId}" placeholder="Enter your reason" style="width: 100%; padding: 8px; margin-top: 4px;">
                    </div>
                    <div class="modal-actions" style="margin-top: 20px; text-align: center;">
                        <button type="button" class="button ${options.confirmClass}" onclick="MyRequestsPage.${options.onConfirm.name}(${options.onConfirm.toString().match(/\(([^)]+)\)/)?.[1] || ''})">
                            ${options.confirmText}
                        </button>
                        <button type="button" class="button button-secondary" onclick="MyRequestsPage.closeModal()">
                            Keep Request
                        </button>
                    </div>
                </form>
            `;
        } else {
            formHtml = options.content || '';
        }

        modal.innerHTML = `
            <div class="request-modal-content">
                <h3>${options.title}</h3>
                ${options.message ? `<p>${options.message}</p>` : ''}
                ${formHtml}
                ${options.showCancel ? `
                    <div class="modal-actions" style="margin-top: 20px; text-align: center;">
                        <button type="button" class="button button-secondary" onclick="MyRequestsPage.closeModal()">
                            ${options.cancelText || 'Close'}
                        </button>
                    </div>
                ` : ''}
            </div>
        `;

        // Store callback references
        modal._onConfirm = options.onConfirm;
        modal._otherInputId = options.otherInputId;

        document.body.appendChild(modal);

        // Bind radio events after modal is in DOM
        if (options.radioName) {
            modal.addEventListener('change', (e) => {
                if (e.target && e.target.name === options.radioName) {
                    const otherInput = document.getElementById(`${options.otherInputId}Input`);
                    if (otherInput) {
                        otherInput.style.display = e.target.value === 'Other' ? 'block' : 'none';
                    }
                }
            });
        }
    },

    /**
     * Bind radio button toggle for "Other" option
     * @param {string} radioName - Radio group name
     * @param {string} otherInputId - Other input container ID
     */
    bindRadioToggle(radioName, otherInputId) {
        document.querySelectorAll(`input[name="${radioName}"]`).forEach(radio => {
            radio.addEventListener('change', (e) => {
                const otherInput = document.getElementById(otherInputId);
                if (otherInput) {
                    otherInput.style.display = e.target.value === 'Other' ? 'block' : 'none';
                }
            });
        });
    },

    /**
     * Handle modal confirmation (generic)
     */
    handleModalConfirm() {
        // This is a fallback - specific confirm functions are called directly
    },

    /**
     * Confirm cancel request
     * @param {number} requestIndex - Request index in user's filtered requests
     */
    confirmCancelRequest(requestIndex) {
        const userRequests = AppState.getUserRequests();
        const request = userRequests[requestIndex];
        if (!request || request.status !== 'Pending' || request.student !== AppState.currentUser.fullName) {
            this.closeModal();
            return;
        }

        const selectedReason = document.querySelector('input[name="cancelReason"]:checked');
        let reason = '';

        if (selectedReason && selectedReason.value === 'Other') {
            reason = document.getElementById('other-reason').value.trim();
            if (!reason) {
                alert('Please enter a reason for cancellation');
                return;
            }
        } else if (selectedReason) {
            reason = selectedReason.value;
        } else {
            alert('Please select a reason for cancellation');
            return;
        }

        // Find the actual index in the full requests array
        const allRequests = AppState.getRequests();
        const actualIndex = allRequests.findIndex(r => r === request);

        if (actualIndex !== -1) {
            AppState.updateRequest(actualIndex, {
                status: 'Cancelled',
                cancellationReason: reason
            });
        }

        this.closeModal();
        this.loadRequests();
    },

    /**
     * Confirm decline request
     * @param {number} requestIndex - Request index in user's filtered requests
     */
    confirmDeclineRequest(requestIndex) {
        const userRequests = AppState.getUserRequests();
        const request = userRequests[requestIndex];
        if (!request || request.status !== 'Pending' || request.tutor !== AppState.currentUser.fullName) {
            this.closeModal();
            return;
        }

        const selectedReason = document.querySelector('input[name="declineReason"]:checked');
        let reason = '';

        if (selectedReason && selectedReason.value === 'Other') {
            reason = document.getElementById('declineOtherReason').value.trim();
            if (!reason) {
                alert('Please enter a reason for declining');
                return;
            }
        } else if (selectedReason) {
            reason = selectedReason.value;
        } else {
            alert('Please select a reason for declining');
            return;
        }

        // Find the actual index in the full requests array
        const allRequests = AppState.getRequests();
        const actualIndex = allRequests.findIndex(r => r === request);

        if (actualIndex !== -1) {
            AppState.updateRequest(actualIndex, {
                status: 'Declined',
                declineReason: reason
            });
        }

        this.closeModal();
        this.loadRequests();
    },

    /**
     * Accept request
     * @param {number} requestIndex - Request index in user's filtered requests
     */
    acceptRequest(requestIndex) {
        const userRequests = AppState.getUserRequests();
        const request = userRequests[requestIndex];
        if (!request || request.status !== 'Pending' || request.tutor !== AppState.currentUser.fullName) {
            return;
        }

        // Find the actual index in the full requests array
        const allRequests = AppState.getRequests();
        const actualIndex = allRequests.findIndex(r => r === request);

        if (actualIndex !== -1) {
            AppState.updateRequest(actualIndex, {
                status: 'Accepted'
            });
        }

        this.loadRequests();
    },

    /**
     * Close any open modal
     */
    closeModal() {
        const modals = document.getElementsByClassName('request-modal');
        while (modals.length > 0) {
            modals[0].remove();
        }
    }
};

// Make functions globally accessible for inline onclick handlers
window.MyRequestsPage = MyRequestsPage;

// Auto-initialize when my-requests screen is shown
document.addEventListener('screen:show', (e) => {
    if (e.detail.screenId === 'my-requests-screen') {
        MyRequestsPage.loadRequests();
    }
});

// Bind back button
document.addEventListener('click', (e) => {
    if (e.target.id === 'back-to-dashboard-from-my-requests') {
        Navigation.showScreen('dashboard-screen');
    }
});

// Export
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { MyRequestsPage };
}