/**
 * StudyLink - Tutor Profile Page Logic
 * Displays detailed tutor information
 */

const TutorProfilePage = {
    /**
     * Load and display tutor profile
     * @param {string} tutorId - Tutor ID
     */
    loadProfile(tutorId) {
        const tutorsData = window.TutorsData || {};
        const tutor = tutorsData[tutorId];
        if (!tutor) {
            console.error('Tutor not found:', tutorId);
            Navigation.showScreen('search-results-screen');
            return;
        }

        AppState.currentTutor = tutor;
        this.renderProfile(tutor);
        this.bindEvents();
    },

    /**
     * Render tutor profile HTML
     * @param {Object} tutor - Tutor object
     */
    renderProfile(tutor) {
        const profileContent = document.getElementById('profile-content');
        const stars = Utils.generateStars(tutor.rating);

        profileContent.innerHTML = `
            <div class="tutor-card">
                <div class="tutor-info">
                    <div class="avatar" style="width: 64px; height: 64px; line-height: 64px; font-size: 1.5em;">${Utils.escapeHtml(tutor.initials)}</div>
                    <div class="tutor-details">
                        <h2>${Utils.escapeHtml(tutor.name)}</h2>
                        <div class="rating">
                            <span class="stars">${stars}</span>
                            <span>${tutor.rating} / 5 (${tutor.reviewCount} reviews)</span>
                        </div>
                        <p><strong>Subjects:</strong> ${Utils.escapeHtml(tutor.subjects.join(', '))}</p>
                        <p><strong>Expertise:</strong> ${Utils.escapeHtml(tutor.expertise)}</p>
                        <p><strong>Availability:</strong> ${Utils.escapeHtml(tutor.availability)}</p>
                        <p><strong>Course:</strong> ${Utils.escapeHtml(tutor.course)} • Year ${tutor.yearLevel}</p>
                        <p><strong>Email:</strong> ${Utils.escapeHtml(tutor.email)}</p>
                        ${tutor.isVerified ? '<p><strong>Status:</strong> <span style="color: var(--success-color);">✓ Verified Tutor</span></p>' : ''}
                    </div>
                </div>
                <div class="bio">
                    <strong>About:</strong> ${Utils.escapeHtml(tutor.bio)}
                </div>
                <div class="reviews">
                    <strong>Reviews (${tutor.reviews.length}):</strong>
                    ${tutor.reviews.map(review => `
                        <div class="review-item">
                            <div style="display: flex; justify-content: space-between; margin-bottom: 4px;">
                                <strong>${Utils.escapeHtml(review.author)}</strong>
                                <span>${Utils.generateStars(review.rating)}</span>
                            </div>
                            <p style="font-style: italic; color: var(--secondary-text);">"${Utils.escapeHtml(review.comment)}"</p>
                            <small style="color: var(--muted-text);">${Utils.formatDate(review.date)}</small>
                        </div>
                    `).join('')}
                </div>
                <button class="button button-primary button-block" id="request-session-btn" style="margin-top: 16px;">
                    Request Tutoring Session
                </button>
            </div>
        `;
    },

    /**
     * Bind event listeners
     */
    bindEvents() {
        // Back to results button
        const backBtn = document.getElementById('back-to-results');
        if (backBtn) {
            backBtn.addEventListener('click', () => {
                Navigation.showScreen('search-results-screen');
            });
        }

        // Request session button
        const requestBtn = document.getElementById('request-session-btn');
        if (requestBtn) {
            requestBtn.addEventListener('click', () => {
                if (AppState.currentTutor) {
                    RequestFlowPage.initFlow(AppState.currentTutor.id);
                    Navigation.showScreen('request-session-flow-screen');
                }
            });
        }
    }
};

// Auto-initialize when profile screen is shown
document.addEventListener('screen:show', (e) => {
    if (e.detail.screenId === 'tutor-profile-screen' && AppState.currentTutor) {
        TutorProfilePage.loadProfile(AppState.currentTutor.id);
    }
});

// Export
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { TutorProfilePage };
}
window.TutorProfilePage = TutorProfilePage;