/**
 * StudyLink - Register Page Logic
 * Handles new user registration with validation
 */

const RegisterPage = {
    /**
     * Initialize register page
     */
    init() {
        this.bindEvents();
    },

    /**
     * Bind event listeners
     */
    bindEvents() {
        // Register form submission
        const registerForm = document.getElementById('register-form');
        if (registerForm) {
            registerForm.addEventListener('submit', (e) => this.handleRegister(e));
        }

        // Login link
        const loginLink = document.getElementById('show-login-link');
        if (loginLink) {
            loginLink.addEventListener('click', (e) => {
                e.preventDefault();
                Navigation.showScreen('login-screen');
            });
        }

        // Clear errors on input
        const inputs = ['reg-name', 'reg-email', 'reg-password', 'reg-course'];
        inputs.forEach(id => {
            const input = document.getElementById(id);
            if (input) {
                input.addEventListener('input', () => Utils.clearError(`${id}-error`));
            }
        });
    },

    /**
     * Handle register form submission
     * @param {Event} e - Submit event
     */
    handleRegister(e) {
        e.preventDefault();

        // Get form values
        const fullName = document.getElementById('reg-name').value.trim();
        const email = document.getElementById('reg-email').value.trim();
        const password = document.getElementById('reg-password').value;
        const course = document.getElementById('reg-course').value.trim();

        // Validate required fields
        if (!fullName) {
            Utils.showError('reg-name-error', 'Please enter your full name.');
            document.getElementById('reg-name').focus();
            return;
        }

        if (!email) {
            Utils.showError('reg-email-error', 'Please enter your CSU email address.');
            document.getElementById('reg-email').focus();
            return;
        }

        if (!Utils.validateEmail(email)) {
            Utils.showError('reg-email-error', 'Please enter a valid CSU email address (e.g., student@csu.edu.ph).');
            document.getElementById('reg-email').focus();
            return;
        }

        if (!password) {
            Utils.showError('reg-password-error', 'Please create a password.');
            document.getElementById('reg-password').focus();
            return;
        }

        if (password.length < 6) {
            Utils.showError('reg-password-error', 'Password must be at least 6 characters long.');
            document.getElementById('reg-password').focus();
            return;
        }

        if (!course) {
            Utils.showError('reg-course-error', 'Please enter your course/program.');
            document.getElementById('reg-course').focus();
            return;
        }

        // Clear all errors
        ['reg-name-error', 'reg-email-error', 'reg-password-error', 'reg-course-error']
            .forEach(id => Utils.clearError(id));

        // Show loading state
        const registerBtn = document.getElementById('register-btn');
        const originalBtnText = registerBtn.textContent;
        registerBtn.textContent = 'Creating account...';
        registerBtn.disabled = true;

        // Simulate async registration
        setTimeout(() => {
            // Attempt registration using AppState
            const result = AppState.register({
                fullName,
                email,
                password,
                course
            });

            if (result.success) {
                // Update dashboard user name
                const userNameEl = document.getElementById('user-name');
                if (userNameEl) {
                    userNameEl.textContent = AppState.currentUser.fullName;
                }

                // Clear form
                document.getElementById('register-form').reset();

                // Navigate to dashboard
                Navigation.showScreen('dashboard-screen');
            } else {
                // Show error
                Utils.showError('reg-email-error', result.error);
                document.getElementById('reg-email').focus();
            }

            // Restore button
            registerBtn.textContent = originalBtnText;
            registerBtn.disabled = false;
        }, 300);
    }
};

// Auto-initialize when register screen is shown
document.addEventListener('screen:show', (e) => {
    if (e.detail.screenId === 'register-screen') {
        RegisterPage.init();
    }
});

// Export
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { RegisterPage };
}
window.RegisterPage = RegisterPage;