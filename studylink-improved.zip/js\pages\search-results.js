/**
 * StudyLink - Search Results Page Logic
 * Displays filtered tutor results with search and filter functionality
 */

const SearchResultsPage = {
    /**
     * Initialize search results page
     */
    init() {
        this.updateHeader();
        this.bindEvents();
        this.displayResults();
    },

    /**
     * Update header based on filter state
     */
    updateHeader() {
        const headerTitle = document.getElementById('results-header');
        const searchSummary = document.getElementById('search-summary');
        const headerActions = document.getElementById('results-header-actions');
        const backToSearchBtn = document.getElementById('back-to-search');

        if (AppState.searchState.isShowingFilteredResults) {
            headerTitle.textContent = 'Filtered Tutor Results';
            const filterCount = this.getActiveFilterCount();
            searchSummary.textContent = filterCount > 0
                ? `${filterCount} filter(s) applied`
                : 'All currently available tutors';
            headerActions.innerHTML = `
                <button class="button button-primary" id="modify-filters-btn">
                    Modify Filters
                </button>
            `;
            backToSearchBtn.textContent = 'Back to All Tutors';
        } else {
            headerTitle.textContent = 'Available Tutors';
            searchSummary.textContent = 'All currently available tutors';
            headerActions.innerHTML = `
                <button class="button button-primary" id="filter-tutors-btn">
                    Filter Tutors
                </button>
            `;
            backToSearchBtn.textContent = 'Back to Dashboard';
        }

        // Re-bind events for dynamically added buttons
        this.bindHeaderButtons();
    },

    /**
     * Count active filters
     * @returns {number} Number of active filters
     */
    getActiveFilterCount() {
        const filters = AppState.searchState.lastFilters || {};
        return Object.values(filters).filter(v => v && v !== '').length;
    },

    /**
     * Bind header button events
     */
    bindHeaderButtons() {
        // Filter tutors button (when showing all)
        const filterBtn = document.getElementById('filter-tutors-btn');
        if (filterBtn) {
            filterBtn.addEventListener('click', () => {
                Navigation.showScreen('tutor-search-screen');
            });
        }

        // Modify filters button (when showing filtered)
        const modifyBtn = document.getElementById('modify-filters-btn');
        if (modifyBtn) {
            modifyBtn.addEventListener('click', () => {
                Navigation.showScreen('tutor-search-screen');
            });
        }
    },

    /**
     * Bind event listeners
     */
    bindEvents() {
        // Back button
        const backBtn = document.getElementById('back-to-search');
        if (backBtn) {
            backBtn.addEventListener('click', () => {
                if (AppState.searchState.isShowingFilteredResults) {
                    AppState.searchState.isShowingFilteredResults = false;
                    this.displayResults();
                    Navigation.showScreen('search-results-screen');
                } else {
                    Navigation.showScreen('dashboard-screen');
                }
            });
        }
    },

    /**
     * Display search results based on current filters
     */
    displayResults() {
        const resultsContainer = document.getElementById('results-container');
        const noResultsMessage = document.getElementById('no-results-message');

        // Get filters
        const filters = AppState.searchState.isShowingFilteredResults
            ? AppState.searchState.lastFilters
            : {
                subject: '',
                expertise: '',
                availability: '',
                rating: ''
            };

        // Filter tutors
        const filteredTutors = this.filterTutors(filters);

        // Display results
        if (filteredTutors.length === 0) {
            noResultsMessage.style.display = 'block';
            noResultsMessage.innerHTML = `
                <h3>No tutors found.</h3>
                <p>We couldn't find a tutor matching your selected criteria. Try changing your subject, expertise, or availability filters.</p>
                <button class="button button-primary" id="change-filters-btn">
                    Change Filters
                </button>
            `;
            resultsContainer.innerHTML = '';

            // Bind change filters button
            const changeBtn = document.getElementById('change-filters-btn');
            if (changeBtn) {
                changeBtn.addEventListener('click', () => {
                    Navigation.showScreen('tutor-search-screen');
                });
            }
        } else {
            noResultsMessage.style.display = 'none';
            resultsContainer.innerHTML = filteredTutors.map(tutor => this.createTutorCard(tutor)).join('');

            // Bind view profile buttons
            this.bindViewProfileButtons();
        }
    },

    /**
     * Filter tutors based on criteria
     * @param {Object} filters - Filter criteria
     * @returns {Array} Filtered tutor objects
     */
    filterTutors(filters) {
        const { subject, expertise, availability, rating } = filters;
        const tutorArray = Object.values(window.TutorsData || {});

        return tutorArray.filter(tutor => {
            // Subject filter
            let subjectMatch = true;
            if (subject && subject !== '') {
                subjectMatch = tutor.subjects.includes(subject);
            }
            if (!subjectMatch) return false;

            // Expertise filter
            if (expertise && expertise !== '') {
                if (tutor.expertise.toLowerCase().indexOf(expertise.toLowerCase()) === -1) {
                    return false;
                }
            }

            // Availability filter
            if (availability && availability !== '') {
                let preferredStartMin = 0;
                let preferredEndMin = 24 * 60;

                if (availability === 'morning') {
                    preferredStartMin = 8 * 60;
                    preferredEndMin = 12 * 60;
                } else if (availability === 'afternoon') {
                    preferredStartMin = 13 * 60;
                    preferredEndMin = 17 * 60;
                } else if (availability === 'evening') {
                    preferredStartMin = 18 * 60;
                    preferredEndMin = 21 * 60;
                }

                // Check if tutor has ANY overlap with preferred time on ANY available day
                let hasOverlap = false;
                for (const dayIndex of tutor.availabilityDays) {
                    const tutorStart = tutor.availabilityStart;
                    const tutorEnd = tutor.availabilityEnd;

                    if (tutorStart < preferredEndMin && preferredStartMin < tutorEnd) {
                        hasOverlap = true;
                        break;
                    }
                }

                if (!hasOverlap) return false;
            }

            // Rating filter
            if (rating && rating !== '') {
                if (tutor.rating < parseFloat(rating)) {
                    return false;
                }
            }

            return true;
        });
    },

    /**
     * Create tutor card HTML
     * @param {Object} tutor - Tutor object
     * @returns {string} HTML string
     */
    createTutorCard(tutor) {
        const stars = Utils.generateStars(tutor.rating);
        const subjects = tutor.subjects.slice(0, 3).join(', ') + (tutor.subjects.length > 3 ? '...' : '');

        return `
            <div class="tutor-card" data-tutor-id="${Utils.escapeHtml(tutor.id)}">
                <div class="tutor-info">
                    <div class="avatar">${Utils.escapeHtml(tutor.initials)}</div>
                    <div class="tutor-details">
                        <h2>${Utils.escapeHtml(tutor.name)}</h2>
                        <div class="rating">
                            <span class="stars">${stars}</span>
                            <span>${tutor.rating} / 5 (${tutor.reviewCount} reviews)</span>
                        </div>
                        <p><strong>Subjects:</strong> ${Utils.escapeHtml(subjects)}</p>
                        <p><strong>Expertise:</strong> ${Utils.escapeHtml(tutor.expertise)}</p>
                        <p><strong>Availability:</strong> ${Utils.escapeHtml(tutor.availability)}</p>
                        <p><strong>Course:</strong> ${Utils.escapeHtml(tutor.course)} • Year ${tutor.yearLevel}</p>
                    </div>
                </div>
                <button class="button button-primary view-profile" data-tutor-id="${Utils.escapeHtml(tutor.id)}">
                    View Profile
                </button>
            </div>
        `;
    },

    /**
     * Bind view profile button events
     */
    bindViewProfileButtons() {
        document.querySelectorAll('.view-profile').forEach(button => {
            button.addEventListener('click', (e) => {
                const tutorId = e.target.getAttribute('data-tutor-id');
                TutorProfilePage.loadProfile(tutorId);
                Navigation.showScreen('tutor-profile-screen');
            });
        });
    }
};

// Auto-initialize when search results screen is shown
document.addEventListener('screen:show', (e) => {
    if (e.detail.screenId === 'search-results-screen') {
        SearchResultsPage.init();
    }
});

// Export
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { SearchResultsPage };
}
window.SearchResultsPage = SearchResultsPage;