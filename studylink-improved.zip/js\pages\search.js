/**
 * StudyLink - Tutor Search Page Logic
 * Handles search form and filter controls
 */

const SearchPage = {
    /**
     * Initialize search page
     */
    init() {
        this.bindEvents();
        this.populateSubjectOptions();
    },

    /**
     * Populate subject dropdown with unique subjects from tutor data
     */
    populateSubjectOptions() {
        const subjectSelect = document.getElementById('search-subject');
        if (!subjectSelect) return;

        // Get all unique subjects from tutors
        const allSubjects = new Set();
        Object.values(window.TutorsData || {}).forEach(tutor => {
            tutor.subjects.forEach(subj => allSubjects.add(subj));
        });

        // Keep the first option (placeholder) and add subjects
        const placeholder = subjectSelect.querySelector('option[value=""]');
        subjectSelect.innerHTML = '';
        if (placeholder) {
            subjectSelect.appendChild(placeholder);
        } else {
            const ph = document.createElement('option');
            ph.value = '';
            ph.textContent = 'Select Subject or Course';
            subjectSelect.appendChild(ph);
        }

        // Add subjects in alphabetical order
        Array.from(allSubjects).sort().forEach(subject => {
            const option = document.createElement('option');
            option.value = subject;
            option.textContent = subject;
            subjectSelect.appendChild(option);
        });
    },

    /**
     * Bind event listeners
     */
    bindEvents() {
        // Back to dashboard button
        const backBtn = document.getElementById('back-to-dashboard-from-search');
        if (backBtn) {
            backBtn.addEventListener('click', () => {
                Navigation.showScreen('dashboard-screen');
            });
        }

        // Search form submission
        const searchForm = document.getElementById('tutor-search-form');
        if (searchForm) {
            searchForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.performSearch();
            });
        }

        // Search button
        const searchBtn = document.getElementById('search-tutors-btn');
        if (searchBtn) {
            searchBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.performSearch();
            });
        }

        // Real-time search input (if we add a search input later)
        const subjectSelect = document.getElementById('search-subject');
        if (subjectSelect) {
            subjectSelect.addEventListener('change', () => {
                // Auto-search when subject changes (optional)
            });
        }
    },

    /**
     * Perform search and navigate to results
     */
    performSearch() {
        AppState.searchState.isShowingFilteredResults = true;
        AppState.searchState.lastFilters = this.getFilters();
        AppState.searchState.searchQuery = ''; // Could add text search later
        SearchResultsPage.displayResults();
        Navigation.showScreen('search-results-screen');
    },

    /**
     * Get current filter values from form
     * @returns {Object} Filter object
     */
    getFilters() {
        return {
            subject: document.getElementById('search-subject').value,
            expertise: document.getElementById('filter-expertise').value,
            availability: document.getElementById('filter-availability').value,
            rating: document.getElementById('filter-rating').value
        };
    }
};

// Auto-initialize when search screen is shown
document.addEventListener('screen:show', (e) => {
    if (e.detail.screenId === 'tutor-search-screen') {
        SearchPage.init();
    }
});

// Export
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { SearchPage };
}
window.SearchPage = SearchPage;