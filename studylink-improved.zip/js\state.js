/**
 * StudyLink - Shared Application State
 * Central state management for the application
 */

const AppState = {
    // Navigation history for back button functionality
    navigationHistory: [],

    // Current user data
    currentUser: {
        id: null,
        email: '',
        fullName: '',
        course: '',
        yearLevel: 0,
        role: 'student',
        isTutor: false,
        isLoggedIn: false
    },

    // Current tutor being viewed
    currentTutor: null,

    // Form values cache
    formValues: {},

    // Submitted tutoring requests
    submittedRequests: [],

    // Request flow state (multi-step session request)
    flowState: {
        step: 1, // 1: date, 2: time, 3: details, 4: confirm
        selectedTutorId: null,
        selectedSubject: null,
        selectedDate: null, // YYYY-MM-DD
        selectedTime: null, // HH:mm
        notes: ''
    },

    // Search/filter state
    searchState: {
        isShowingFilteredResults: false,
        lastFilters: {},
        searchQuery: ''
    },

    // Initialize state from localStorage if available
    init() {
        this.loadFromStorage();
    },

    // Save state to localStorage
    saveToStorage() {
        const data = {
            currentUser: this.currentUser,
            submittedRequests: this.submittedRequests,
            formValues: this.formValues
        };
        try {
            localStorage.setItem('studylink_state', JSON.stringify(data));
        } catch (e) {
            console.warn('Failed to save state to localStorage:', e);
        }
    },

    // Load state from localStorage
    loadFromStorage() {
        try {
            const data = JSON.parse(localStorage.getItem('studylink_state'));
            if (data) {
                this.currentUser = data.currentUser || this.currentUser;
                this.submittedRequests = data.submittedRequests || [];
                this.formValues = data.formValues || {};
            }
        } catch (e) {
            console.warn('Failed to load state from localStorage:', e);
        }
    },

    // User authentication methods
    /**
     * Attempt to log in a user with email and password
     * @param {string} email - User's email
     * @param {string} password - User's password
     * @returns {Object} Result object with success boolean and user data or error message
     */
    login(email, password) {
        // Import mock users (available globally as MockUsers)
        const users = window.MockUsers || [];

        // Find user by email
        const user = users.find(u => u.email.toLowerCase() === email.toLowerCase());

        if (!user) {
            return { success: false, error: 'No account found with this email address.' };
        }

        // Check password (in production, use proper password hashing)
        if (user.password !== password) {
            return { success: false, error: 'Incorrect password. Please try again.' };
        }

        // Login successful - set user data
        this.currentUser = {
            id: user.id,
            email: user.email,
            fullName: user.fullName,
            course: user.course,
            yearLevel: user.yearLevel,
            role: user.role,
            isTutor: user.isTutor,
            isLoggedIn: true
        };

        this.saveToStorage();
        return { success: true, user: this.currentUser };
    },

    logout() {
        this.currentUser = {
            id: null,
            email: '',
            fullName: '',
            course: '',
            yearLevel: 0,
            role: 'student',
            isTutor: false,
            isLoggedIn: false
        };
        this.currentTutor = null;
        this.formValues = {};
        this.navigationHistory = [];
        this.saveToStorage();
    },

    /**
     * Register a new user (mock implementation)
     * @param {Object} userData - User registration data
     * @returns {Object} Result object
     */
    register(userData) {
        const users = window.MockUsers || [];

        // Check if email already exists
        if (users.some(u => u.email.toLowerCase() === userData.email.toLowerCase())) {
            return { success: false, error: 'An account with this email already exists.' };
        }

        // In a real app, this would send to backend
        // For mock, we'll just simulate success
        const newUser = {
            id: 'user_' + Date.now(),
            email: userData.email,
            password: userData.password, // In production: hash this!
            fullName: userData.fullName,
            course: userData.course,
            yearLevel: parseInt(userData.yearLevel) || 1,
            role: 'student',
            isTutor: false,
            createdAt: new Date().toISOString()
        };

        // Add to mock users (in memory only)
        window.MockUsers.push(newUser);

        // Auto-login the new user
        return this.login(userData.email, userData.password);
    },

    /**
     * Check if user is authenticated
     * @returns {boolean}
     */
    isAuthenticated() {
        return this.currentUser.isLoggedIn === true;
    },

    /**
     * Check if current user has a specific role
     * @param {string} role - Role to check
     * @returns {boolean}
     */
    hasRole(role) {
        return this.currentUser.role === role;
    },

    // Navigation methods
    pushHistory(screenId) {
        if (!['login-screen', 'register-screen'].includes(screenId)) {
            this.navigationHistory.push(screenId);
        }
    },

    popHistory() {
        if (this.navigationHistory.length > 0) {
            this.navigationHistory.pop(); // Remove current
            return this.navigationHistory.pop() || 'dashboard-screen'; // Return previous
        }
        return 'login-screen';
    },

    clearHistory() {
        this.navigationHistory = [];
    },

    // Request flow methods
    initFlow(tutorId) {
        this.flowState = {
            step: 1,
            selectedTutorId: tutorId,
            selectedSubject: null,
            selectedDate: null,
            selectedTime: null,
            notes: ''
        };
    },

    resetFlow() {
        this.flowState = {
            step: 1,
            selectedTutorId: null,
            selectedSubject: null,
            selectedDate: null,
            selectedTime: null,
            notes: ''
        };
    },

    // Request management
    addRequest(request) {
        this.submittedRequests.push(request);
        this.saveToStorage();
    },

    updateRequest(index, updates) {
        if (this.submittedRequests[index]) {
            this.submittedRequests[index] = {
                ...this.submittedRequests[index],
                ...updates
            };
            this.saveToStorage();
        }
    },

    getRequests() {
        return this.submittedRequests;
    },

    /**
     * Get requests for current user (as student or tutor)
     * @returns {Array} Filtered requests
     */
    getUserRequests() {
        const userName = this.currentUser.fullName;
        return this.submittedRequests.filter(req =>
            req.student === userName || req.tutor === userName
        );
    }
};

// Export for module usage
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { AppState };
}

// Make available globally for non-module usage
window.AppState = AppState;