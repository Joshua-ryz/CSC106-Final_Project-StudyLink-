# StudyLink - Modular Peer Tutoring System

A modular, multi-file refactoring of the StudyLink prototype for Caraga State University students.

## Project Structure

```
studylink-modular/
├── index.html              # Main HTML file with all screens
├── README.md               # This file
├── css/
│   ├── global.css          # Global styles (design tokens, base, components)
│   ├── login.css           # Login/Register page styles
│   ├── dashboard.css       # Dashboard page styles
│   ├── search.css          # Search & Results page styles
│   ├── profile.css         # Tutor Profile page styles
│   ├── request.css         # Request Session Flow page styles
│   ├── confirmation.css    # Confirmation page styles
│   └── my-requests.css     # My Requests page styles
├── js/
│   ├── app.js              # Main application entry point
│   ├── state.js            # Shared application state management
│   ├── navigation.js       # Screen navigation and history
│   ├── utils.js            # Utility functions
│   ├── tutors.js           # Tutor data access and filtering
│   └── pages/
│       ├── login.js        # Login page logic
│       ├── register.js     # Register page logic
│       ├── dashboard.js    # Dashboard page logic
│       ├── search.js       # Tutor Search page logic
│       ├── search-results.js # Search Results page logic
│       ├── profile.js      # Tutor Profile page logic
│       ├── request-flow.js # Request Session Flow logic (multi-step)
│       ├── confirmation.js # Confirmation page logic
│       └── my-requests.js  # My Requests page logic
├── data/
│   └── tutors.js           # Tutor data (sample data)
└── assets/                 # Images and other assets (if any)
```

## Features

- **Login/Registration**: Student authentication (prototype only)
- **Dashboard**: Welcome screen with quick actions
- **Tutor Search**: Filter tutors by subject, expertise, availability, and rating
- **Search Results**: View filtered or all available tutors
- **Tutor Profile**: Detailed tutor information with bio, reviews, and ratings
- **Request Session Flow**: 4-step wizard (Date → Time → Details → Confirm)
- **Confirmation**: Request submission confirmation
- **My Requests**: View and manage tutoring requests (cancel, accept, decline)
- **Responsive Design**: Works on mobile and desktop
- **Dark Mode Support**: Automatic via `prefers-color-scheme`
- **Accessibility**: ARIA labels, semantic HTML, keyboard navigation

## How to Run

### Option 1: VS Code Live Server (Recommended)

1. Open the `studylink-modular` folder in VS Code
2. Install the "Live Server" extension if not already installed
3. Right-click `index.html` and select "Open with Live Server"
4. The app will open in your default browser

### Option 2: Python HTTP Server

```bash
cd studylink-modular
python -m http.server 8000
```

Then open `http://localhost:8000` in your browser.

### Option 3: Node.js http-server

```bash
cd studylink-modular
npx http-server
```

Then open the provided URL in your browser.

### Option 4: Direct File Open

Simply double-click `index.html` to open it directly in your browser.
*Note: Some features may be limited due to CORS restrictions when opening files directly.*

## Application Flow

1. **Login/Register** → Enter CSU email to access the system
2. **Dashboard** → Choose "Find a Tutor" or "My Requests"
3. **Find Tutor** → Set search filters (subject, expertise, availability, rating)
4. **Search Results** → View matching tutors, click "View Profile"
5. **Tutor Profile** → Review tutor details, click "Request Tutoring Session"
6. **Request Session** → 4-step flow:
   - Step 1: Select Date (based on tutor availability)
   - Step 2: Select Time (30-min slots)
   - Step 3: Session Details (subject, notes)
   - Step 4: Confirm & Submit
7. **Confirmation** → Request sent, view status in "My Requests"
8. **My Requests** → View all requests, cancel (student) or accept/decline (tutor)

## Key Design Decisions

### Modular Architecture
- Each page has its own JavaScript module in `js/pages/`
- Shared state managed through `AppState` singleton
- Navigation handled by `Navigation` module
- Tutor data accessed through `Tutors` module
- Utilities in `Utils` module

### CSS Organization
- `global.css` contains all design tokens, base styles, and shared components
- Page-specific CSS files only contain overrides or unique styles
- CSS custom properties (variables) for theming
- Dark mode via `prefers-color-scheme` media query

### State Management
- `AppState` persists to `localStorage` for session persistence
- Navigation history enables back button functionality
- Request flow state managed separately for multi-step wizard

## Browser Support

- Chrome/Edge 88+
- Firefox 78+
- Safari 14+
- Mobile browsers (iOS Safari, Chrome for Android)

## Customization

### Adding New Tutors
Edit `data/tutors.js` and add new tutor objects following the existing structure.

### Modifying Styles
- Design tokens in `css/global.css` `:root` section
- Page-specific styles in respective CSS files
- Dark mode tokens in `@media (prefers-color-scheme: dark)` block

### Extending Functionality
- Add new pages by creating HTML sections in `index.html`
- Create corresponding CSS in `css/` and JS in `js/pages/`
- Register screen show handlers using `document.addEventListener('screen:show', ...)`

## License

Prototype for educational purposes - Caraga State University