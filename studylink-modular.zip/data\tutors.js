// Tutor data for StudyLink
// Shared data module - can be imported by any page

const tutors = {
    maria: {
        id: 'maria',
        name: 'Maria Santos',
        initials: 'MS',
        subjects: ['Mathematics'],
        expertise: 'Intermediate to Advanced Level',
        availability: 'Mondays, Wednesdays, Fridays (3:00 PM - 6:00 PM)',
        availabilityDays: [1, 3, 5], // Monday, Wednesday, Friday
        availabilityStart: 15 * 60, // 15:00 in minutes
        availabilityEnd: 18 * 60,   // 18:00 in minutes
        rating: 4.8,
        bio: 'Experienced math tutor with 3 years of teaching experience. Specializes in helping students understand complex mathematical concepts through practical examples.',
        topics: ['Quadratic Equations', 'Trigonometry', 'Calculus Fundamentals'],
        reviews: [
            'Maria helped me improve my math grade from C to A in just one semester!',
            'Very patient and explains concepts clearly. Highly recommend!'
        ]
    },
    juan: {
        id: 'juan',
        name: 'Juan dela Cruz',
        initials: 'JdC',
        subjects: ['Programming', 'Java Programming', 'Data Structures and Algorithms'],
        expertise: 'Beginner to Intermediate Level',
        availability: 'Tuesdays, Thursdays (4:00 PM - 7:00 PM)',
        availabilityDays: [2, 4], // Tuesday, Thursday
        availabilityStart: 16 * 60, // 16:00
        availabilityEnd: 19 * 60,   // 19:00
        rating: 4.2,
        bio: 'Computer Science senior with experience in Java and Python programming. Helps students with coding assignments and programming concepts.',
        topics: ['Object-Oriented Programming', 'Algorithms', 'Web Development Basics'],
        reviews: [
            'Juan helped me debug my final project and get it working!',
            'Great tutor for programming beginners. Very knowledgeable.'
        ]
    },
    anna: {
        id: 'anna',
        name: 'Anna Rodriguez',
        initials: 'AR',
        subjects: ['English', 'Literature', 'Writing', 'Communication'],
        expertise: 'All Levels',
        availability: 'Weekends (9:00 AM - 12:00 PM)',
        availabilityDays: [0, 6], // Saturday, Sunday
        availabilityStart: 9 * 60,  // 09:00
        availabilityEnd: 12 * 60,   // 12:00
        rating: 4.5,
        bio: 'English Literature graduate passionate about helping students improve their writing and communication skills.',
        topics: ['Essay Writing', 'Literary Analysis', 'Public Speaking'],
        reviews: [
            'Anna helped me improve my essay writing skills significantly.',
            'Very encouraging and helpful with literature assignments.'
        ]
    }
};

// Export for module usage
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { tutors };
}