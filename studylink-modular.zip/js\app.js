/**
 * StudyLink - Main Application Entry Point
 * Initializes core modules and sets up global event handlers
 */

// Import modules (for reference - using global namespace in browser)
// import { AppState } from './state.js';
// import { Navigation } from './navigation.js';
// import { Utils } from './utils.js';
// import { Tutors } from './tutors.js';

/**
 * Initialize the application
 */
function initApp() {
    // Initialize core state
    AppState.init();

    // Initialize tutor data
    if (typeof tutorsData !== 'undefined') {
        Tutors.init(tutorsData);
    }

    // Initialize navigation (creates progress strip)
    Navigation.initProgressStrip();

    // Set up top bar navigation
    setupTopBarNavigation();

    // Set up global back button handling
    setupGlobalBackButtons();

    // Show initial screen based on auth state
    if (AppState.currentUser.isLoggedIn) {
        document.getElementById('user-name').textContent = AppState.currentUser.name;
        Navigation.showScreen('dashboard-screen');
    } else {
        Navigation.showScreen('login-screen');
    }

    console.log('StudyLink initialized');
}

/**
 * Set up top bar navigation links
 */
function setupTopBarNavigation() {
    // Dashboard link
    const navDashboard = document.getElementById('nav-dashboard');
    if (navDashboard) {
        navDashboard.addEventListener('click', (e) => {
            e.preventDefault();
            Navigation.showScreen('dashboard-screen');
        });
    }

    // My Requests link
    const navMyRequests = document.getElementById('nav-my-requests');
    if (navMyRequests) {
        navMyRequests.addEventListener('click', (e) => {
            e.preventDefault();
            MyRequestsPage.loadRequests();
            Navigation.showScreen('my-requests-screen');
        });
    }

    // Logout link
    const navLogout = document.getElementById('nav-logout');
    if (navLogout) {
        navLogout.addEventListener('click', (e) => {
            e.preventDefault();
            handleLogout();
        });
    }
}

/**
 * Set up global back buttons
 */
function setupGlobalBackButtons() {
    // Back to dashboard from search
    const backToDashboardFromSearch = document.getElementById('back-to-dashboard-from-search');
    if (backToDashboardFromSearch) {
        backToDashboardFromSearch.addEventListener('click', () => {
            Navigation.showScreen('dashboard-screen');
        });
    }

    // Back to dashboard from my requests
    const backToDashboardFromMyRequests = document.getElementById('back-to-dashboard-from-my-requests');
    if (backToDashboardFromMyRequests) {
        backToDashboardFromMyRequests.addEventListener('click', () => {
            Navigation.showScreen('dashboard-screen');
        });
    }

    // Back to dashboard from confirmation
    const backToDashboardFromConfirm = document.getElementById('back-to-dashboard-from-confirm');
    if (backToDashboardFromConfirm) {
        backToDashboardFromConfirm.addEventListener('click', () => {
            Navigation.showScreen('dashboard-screen');
        });
    }

    // Back to search from results
    const backToSearch = document.getElementById('back-to-search');
    if (backToSearch) {
        backToSearch.addEventListener('click', () => {
            if (AppState.searchState.isShowingFilteredResults) {
                AppState.searchState.isShowingFilteredResults = false;
                SearchResultsPage.displayResults();
                Navigation.showScreen('search-results-screen');
            } else {
                Navigation.showScreen('dashboard-screen');
            }
        });
    }

    // Back to results from profile
    const backToResults = document.getElementById('back-to-results');
    if (backToResults) {
        backToResults.addEventListener('click', () => {
            Navigation.showScreen('search-results-screen');
        });
    }

    // Back to profile from request flow
    const backToProfileFromFlow = document.getElementById('back-to-profile-from-flow');
    if (backToProfileFromFlow) {
        backToProfileFromFlow.addEventListener('click', () => {
            Navigation.showScreen('tutor-profile-screen');
        });
    }
}

/**
 * Handle user logout
 */
function handleLogout() {
    AppState.logout();

    // Clear form inputs
    const loginEmail = document.getElementById('login-email');
    const loginPassword = document.getElementById('login-password');
    if (loginEmail) loginEmail.value = '';
    if (loginPassword) loginPassword.value = '';

    // Reset user name
    const userName = document.getElementById('user-name');
    if (userName) userName.textContent = 'Student!';

    // Hide top bar
    const topBar = document.getElementById('top-bar');
    if (topBar) topBar.classList.remove('active');

    // Navigate to login
    Navigation.showScreen('login-screen');
}

// Initialize app when DOM is ready
document.addEventListener('DOMContentLoaded', initApp);

// Export for module usage
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { initApp, handleLogout };
}