/**
 * StudyLink - Confirmation Page Logic
 */

const ConfirmationPage = {
    /**
     * Initialize confirmation page
     */
    init() {
        this.bindEvents();
    },

    /**
     * Bind event listeners
     */
    bindEvents() {
        // Back to dashboard button
        const backBtn = document.getElementById('back-to-dashboard-from-confirm');
        if (backBtn) {
            backBtn.addEventListener('click', () => {
                Navigation.showScreen('dashboard-screen');
            });
        }

        // Back to dashboard button (in confirmation message)
        const confirmBackDash = document.getElementById('confirm-back-dash');
        if (confirmBackDash) {
            confirmBackDash.addEventListener('click', () => {
                Navigation.showScreen('dashboard-screen');
            });
        }

        // View requests button
        const viewRequestsBtn = document.getElementById('view-requests-btn');
        if (viewRequestsBtn) {
            viewRequestsBtn.addEventListener('click', () => {
                MyRequestsPage.loadRequests();
                Navigation.showScreen('my-requests-screen');
            });
        }
    }
};

// Auto-initialize when confirmation screen is shown
document.addEventListener('screen:show', (e) => {
    if (e.detail.screenId === 'confirmation-screen') {
        ConfirmationPage.init();
    }
});

// Export
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { ConfirmationPage };
}
window.ConfirmationPage = ConfirmationPage;