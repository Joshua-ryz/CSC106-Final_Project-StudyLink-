/**
 * StudyLink - Dashboard Page Logic
 */

const DashboardPage = {
    /**
     * Initialize dashboard page
     */
    init() {
        this.updateWelcomeMessage();
        this.bindEvents();
    },

    /**
     * Update welcome message with user name
     */
    updateWelcomeMessage() {
        const userNameEl = document.getElementById('user-name');
        if (userNameEl && AppState.currentUser.name) {
            userNameEl.textContent = AppState.currentUser.name;
        }
    },

    /**
     * Bind event listeners
     */
    bindEvents() {
        // Find tutor button
        const findTutorBtn = document.getElementById('find-tutor-btn');
        if (findTutorBtn) {
            findTutorBtn.addEventListener('click', () => {
                // Reset search form
                const searchForm = document.getElementById('tutor-search-form');
                if (searchForm) searchForm.reset();
                AppState.searchState.isShowingFilteredResults = false;
                SearchResultsPage.displayResults();
                Navigation.showScreen('search-results-screen');
            });
        }

        // My requests button
        const myRequestsBtn = document.getElementById('my-requests-btn');
        if (myRequestsBtn) {
            myRequestsBtn.addEventListener('click', () => {
                MyRequestsPage.loadRequests();
                Navigation.showScreen('my-requests-screen');
            });
        }
    }
};

// Auto-initialize when dashboard screen is shown
document.addEventListener('screen:show', (e) => {
    if (e.detail.screenId === 'dashboard-screen') {
        DashboardPage.init();
    }
});

// Export
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { DashboardPage };
}
window.DashboardPage = DashboardPage;