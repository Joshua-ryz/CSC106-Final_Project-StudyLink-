/**
 * StudyLink - Login Page Logic
 */

const LoginPage = {
    /**
     * Initialize login page
     */
    init() {
        this.bindEvents();
        this.checkRedirect();
    },

    /**
     * Check if user should be redirected (already logged in)
     */
    checkRedirect() {
        if (AppState.currentUser.isLoggedIn) {
            Navigation.showScreen('dashboard-screen');
        }
    },

    /**
     * Bind event listeners
     */
    bindEvents() {
        // Login form submission
        const loginForm = document.getElementById('login-form');
        if (loginForm) {
            loginForm.addEventListener('submit', (e) => this.handleLogin(e));
        }

        // Register link
        const registerLink = document.getElementById('show-register-link');
        if (registerLink) {
            registerLink.addEventListener('click', (e) => {
                e.preventDefault();
                Navigation.showScreen('register-screen');
            });
        }
    },

    /**
     * Handle login form submission
     * @param {Event} e - Submit event
     */
    handleLogin(e) {
        e.preventDefault();

        const emailInput = document.getElementById('login-email');
        const emailError = document.getElementById('login-email-error');
        const email = emailInput.value.trim();

        // Basic validation
        if (!Utils.validateEmail(email)) {
            Utils.showError('login-email-error', 'Please enter a valid CSU email address');
            emailInput.focus();
            return;
        }

        Utils.clearError('login-email-error');

        // Login user
        AppState.login(email);

        // Update dashboard user name
        document.getElementById('user-name').textContent = AppState.currentUser.name;

        // Navigate to dashboard
        Navigation.showScreen('dashboard-screen');
    }
};

// Auto-initialize when login screen is shown
document.addEventListener('screen:show', (e) => {
    if (e.detail.screenId === 'login-screen') {
        LoginPage.init();
    }
});

// Export
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { LoginPage };
}
window.LoginPage = LoginPage;