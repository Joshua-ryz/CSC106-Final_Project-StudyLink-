/**
 * StudyLink - Tutor Profile Page Logic
 */

const TutorProfilePage = {
    /**
     * Load and display tutor profile
     * @param {string} tutorId - Tutor ID
     */
    loadProfile(tutorId) {
        const tutor = Tutors.getById(tutorId);
        if (!tutor) return;

        AppState.currentTutor = tutor;
        this.renderProfile(tutor);
        this.bindEvents();
    },

    /**
     * Render tutor profile HTML
     * @param {Object} tutor - Tutor object
     */
    renderProfile(tutor) {
        const profileContent = document.getElementById('profile-content');
        const stars = Utils.generateStars(tutor.rating);

        profileContent.innerHTML = `
            <div class="tutor-card">
                <div class="tutor-info">
                    <div class="avatar">${Utils.escapeHtml(tutor.initials)}</div>
                    <div class="tutor-details">
                        <h2>${Utils.escapeHtml(tutor.name)}</h2>
                        <div class="rating">
                            <span class="stars">${stars}</span>
                            <span>${tutor.rating} / 5</span>
                        </div>
                        <p><strong>Subjects:</strong> ${Utils.escapeHtml(tutor.subjects.join(', '))}</p>
                        <p><strong>Expertise:</strong> ${Utils.escapeHtml(tutor.expertise)}</p>
                        <p><strong>Availability:</strong> ${Utils.escapeHtml(tutor.availability)}</p>
                    </div>
                </div>
                <div class="bio">
                    <strong>Bio:</strong> ${Utils.escapeHtml(tutor.bio)}
                </div>
                <div class="reviews">
                    <strong>Sample Reviews:</strong>
                    ${tutor.reviews.map(review => `
                        <div class="review-item">"${Utils.escapeHtml(review)}"</div>
                    `).join('')}
                </div>
                <button class="button button-primary button-block" id="request-session-btn">
                    Request Tutoring Session
                </button>
            </div>
        `;
    },

    /**
     * Bind event listeners
     */
    bindEvents() {
        // Back to results button
        const backBtn = document.getElementById('back-to-results');
        if (backBtn) {
            backBtn.addEventListener('click', () => {
                Navigation.showScreen('search-results-screen');
            });
        }

        // Request session button
        const requestBtn = document.getElementById('request-session-btn');
        if (requestBtn) {
            requestBtn.addEventListener('click', () => {
                if (AppState.currentTutor) {
                    RequestFlowPage.initFlow(AppState.currentTutor.id);
                    Navigation.showScreen('request-session-flow-screen');
                }
            });
        }
    }
};

// Auto-initialize when profile screen is shown
document.addEventListener('screen:show', (e) => {
    if (e.detail.screenId === 'tutor-profile-screen' && AppState.currentTutor) {
        TutorProfilePage.loadProfile(AppState.currentTutor.id);
    }
});

// Export
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { TutorProfilePage };
}
window.TutorProfilePage = TutorProfilePage;