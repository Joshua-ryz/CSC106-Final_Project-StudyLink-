/**
 * StudyLink - Register Page Logic
 */

const RegisterPage = {
    /**
     * Initialize register page
     */
    init() {
        this.bindEvents();
    },

    /**
     * Bind event listeners
     */
    bindEvents() {
        // Register form submission
        const registerForm = document.getElementById('register-form');
        if (registerForm) {
            registerForm.addEventListener('submit', (e) => this.handleRegister(e));
        }

        // Login link
        const loginLink = document.getElementById('show-login-link');
        if (loginLink) {
            loginLink.addEventListener('click', (e) => {
                e.preventDefault();
                Navigation.showScreen('login-screen');
            });
        }
    },

    /**
     * Handle register form submission
     * @param {Event} e - Submit event
     */
    handleRegister(e) {
        e.preventDefault();

        const emailInput = document.getElementById('reg-email');
        const emailError = document.getElementById('reg-email-error');
        const email = emailInput.value.trim();

        // Basic validation
        if (!Utils.validateEmail(email)) {
            Utils.showError('reg-email-error', 'Please enter a valid CSU email address');
            emailInput.focus();
            return;
        }

        Utils.clearError('reg-email-error');

        // In a real app, this would create an account
        // For prototype, just go to dashboard
        AppState.login(email);
        document.getElementById('user-name').textContent = AppState.currentUser.name;

        Navigation.showScreen('dashboard-screen');
    }
};

// Auto-initialize when register screen is shown
document.addEventListener('screen:show', (e) => {
    if (e.detail.screenId === 'register-screen') {
        RegisterPage.init();
    }
});

// Export
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { RegisterPage };
}
window.RegisterPage = RegisterPage;