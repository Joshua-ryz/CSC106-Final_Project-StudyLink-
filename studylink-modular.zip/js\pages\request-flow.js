/**
 * StudyLink - Request Session Flow Page Logic
 * Multi-step flow: Date Selection -> Time Selection -> Session Details -> Confirmation
 */

const RequestFlowPage = {
    /**
     * Initialize request flow for a tutor
     * @param {string} tutorId - Tutor ID
     */
    initFlow(tutorId) {
        AppState.initFlow(tutorId);
        this.updateStepIndicator();
        this.showStep(1);
    },

    /**
     * Update step indicator UI
     */
    updateStepIndicator() {
        const step = AppState.flowState.step;
        document.getElementById('step1').classList.toggle('active', step === 1);
        document.getElementById('step2').classList.toggle('active', step === 2);
        document.getElementById('step3').classList.toggle('active', step === 3);
        document.getElementById('step4').classList.toggle('active', step === 4);
    },

    /**
     * Show specific step
     * @param {number} stepNum - Step number (1-4)
     */
    showStep(stepNum) {
        // Hide all steps
        document.querySelectorAll('#step-date, #step-time, #step-details, #step-confirm')
            .forEach(el => el.classList.remove('active'));

        // Show current step
        const stepIds = {
            1: 'step-date',
            2: 'step-time',
            3: 'step-details',
            4: 'step-confirm'
        };

        const stepId = stepIds[stepNum];
        if (stepId) {
            document.getElementById(stepId).classList.add('active');
        }

        // Reset button states
        this.resetButtonStates();

        // Clear errors
        this.clearAllErrors();

        // Load step content
        switch (stepNum) {
            case 1: this.loadDateOptions(); break;
            case 2: this.loadTimeOptions(); break;
            case 3: this.loadDetails(); break;
            case 4: this.loadConfirmation(); break;
        }
    },

    /**
     * Reset all button states
     */
    resetButtonStates() {
        document.getElementById('date-next-btn').disabled = true;
        document.getElementById('time-back-btn').disabled = false;
        document.getElementById('time-next-btn').disabled = true;
        document.getElementById('details-back-btn').disabled = false;
        document.getElementById('details-next-btn').disabled = true;
        document.getElementById('confirm-back-btn').disabled = false;
        document.getElementById('confirm-submit-btn').disabled = true;
    },

    /**
     * Clear all error messages
     */
    clearAllErrors() {
        ['date-error', 'time-error', 'details-error', 'confirm-error', 'flow-custom-subject-error']
            .forEach(id => Utils.clearError(id));
    },

    // ============ STEP 1: DATE SELECTION ============

    /**
     * Load available date options
     */
    loadDateOptions() {
        const tutor = Tutors.getById(AppState.flowState.selectedTutorId);
        if (!tutor) return;

        const dates = Tutors.getAvailableDates(AppState.flowState.selectedTutorId);
        const dateGrid = document.getElementById('date-grid');
        dateGrid.innerHTML = '';

        if (dates.length === 0) {
            dateGrid.innerHTML = '<p style="text-align: center; color: var(--muted-text);">No available dates in the next two weeks.</p>';
            return;
        }

        dates.forEach(dateStr => {
            const btn = document.createElement('button');
            btn.className = 'date-btn';
            btn.textContent = Utils.formatDate(dateStr);
            btn.dataset.date = dateStr;
            btn.addEventListener('click', () => this.selectDate(btn, dateStr));
            dateGrid.appendChild(btn);
        });

        // Restore previously selected date
        if (AppState.flowState.selectedDate) {
            const selectedBtn = dateGrid.querySelector(`.date-btn[data-date="${AppState.flowState.selectedDate}"]`);
            if (selectedBtn) {
                selectedBtn.classList.add('active');
                document.getElementById('date-next-btn').disabled = false;
            }
        } else if (dates.length > 0) {
            // Auto-select first date for demo
            const firstBtn = dateGrid.querySelector('.date-btn');
            if (firstBtn) firstBtn.click();
        }
    },

    /**
     * Handle date selection
     * @param {HTMLElement} btn - Clicked button
     * @param {string} dateStr - Selected date
     */
    selectDate(btn, dateStr) {
        document.querySelectorAll('.date-btn.active').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        AppState.flowState.selectedDate = dateStr;
        Utils.clearError('date-error');
        document.getElementById('date-next-btn').disabled = false;
    },

    // ============ STEP 2: TIME SELECTION ============

    /**
     * Load available time slots
     */
    loadTimeOptions() {
        if (!AppState.flowState.selectedDate) {
            Utils.showError('time-error', 'Please select a date first.');
            return;
        }

        const slots = Tutors.getTimeSlots(AppState.flowState.selectedTutorId, AppState.flowState.selectedDate);
        const timeGrid = document.getElementById('time-grid');
        timeGrid.innerHTML = '';

        slots.forEach(slot => {
            const btn = document.createElement('button');
            btn.className = `time-slot ${slot.booked ? 'booked' : slot.available ? 'available' : 'unavailable'}`;
            btn.textContent = Utils.formatTime(slot.time);
            btn.dataset.time = slot.time;
            btn.disabled = slot.booked || !slot.available;

            if (!slot.booked && slot.available) {
                btn.addEventListener('click', () => this.selectTime(btn, slot.time));
            }
            timeGrid.appendChild(btn);
        });

        // Restore previously selected time
        if (AppState.flowState.selectedTime) {
            const selectedBtn = timeGrid.querySelector(`.time-slot[data-time="${AppState.flowState.selectedTime}"]`);
            if (selectedBtn && !selectedBtn.disabled) {
                selectedBtn.classList.add('selected');
                document.getElementById('time-next-btn').disabled = false;
            }
        } else {
            // Auto-select first available slot
            const firstAvailable = timeGrid.querySelector('.time-slot.available:not(.selected)');
            if (firstAvailable) firstAvailable.click();
        }
    },

    /**
     * Handle time selection
     * @param {HTMLElement} btn - Clicked button
     * @param {string} timeStr - Selected time
     */
    selectTime(btn, timeStr) {
        document.querySelectorAll('.time-slot.selected').forEach(b => b.classList.remove('selected'));
        btn.classList.add('selected');
        AppState.flowState.selectedTime = timeStr;
        Utils.clearError('time-error');
        document.getElementById('time-next-btn').disabled = false;
    },

    // ============ STEP 3: SESSION DETAILS ============

    /**
     * Load session details step
     */
    loadDetails() {
        if (!AppState.flowState.selectedDate || !AppState.flowState.selectedTime) {
            Utils.showError('details-error', 'Please select date and time first.');
            return;
        }

        const tutor = Tutors.getById(AppState.flowState.selectedTutorId);
        if (!tutor) return;

        // Update tutor and subject preview
        document.getElementById('flow-selected-tutor-name').textContent = tutor.name;
        document.getElementById('flow-selected-subject').textContent = tutor.subjects[0];
        document.getElementById('flow-session-date').textContent = Utils.formatDate(AppState.flowState.selectedDate);
        document.getElementById('flow-session-time').textContent = Utils.formatTime(AppState.flowState.selectedTime);
        document.getElementById('flow-session-notes').value = AppState.flowState.notes || '';

        // Add subject selector if not already added
        this.addSubjectSelector(tutor);

        // Validate details
        this.validateDetails();
    },

    /**
     * Add subject selector dropdown
     * @param {Object} tutor - Tutor object
     */
    addSubjectSelector(tutor) {
        // Check if already added
        if (document.getElementById('flow-subject-select')) return;

        const subjectSelect = document.createElement('select');
        subjectSelect.id = 'flow-subject-select';
        subjectSelect.required = true;

        tutor.subjects.forEach(subj => {
            const option = document.createElement('option');
            option.value = subj;
            option.textContent = subj;
            subjectSelect.appendChild(option);
        });

        // Add "Other" option
        const otherOption = document.createElement('option');
        otherOption.value = 'other';
        otherOption.textContent = 'Other (please specify)';
        subjectSelect.appendChild(otherOption);

        const subjectGroup = document.createElement('div');
        subjectGroup.className = 'form-group';
        subjectGroup.innerHTML = `
            <label for="flow-subject-select">Subject</label>
            <div class="custom-subject-input" id="flow-custom-subject-container">
                <label for="flow-custom-subject" style="display: block; margin-bottom: 4px; font-weight: 600; font-size: 0.95em; color: var(--text-color);">
                    Please specify your subject:
                </label>
                <input type="text" id="flow-custom-subject" placeholder="Enter your subject" style="width: 100%; padding: 12px; border: 2px solid var(--border-color); background-color: var(--bg-color); font-size: 1em; border-radius: var(--radius); transition: var(--transition);">
                <div class="error-message" id="flow-custom-subject-error" role="alert"></div>
            </div>
        `;
        subjectGroup.insertBefore(subjectSelect, subjectGroup.firstChild.nextSibling);

        // Insert after tutor preview
        const detailsContainer = document.getElementById('step-details');
        const tutorPreview = detailsContainer.querySelector('.tutor-preview');
        tutorPreview.insertAdjacentElement('afterend', subjectGroup);

        // Bind events
        subjectSelect.addEventListener('change', (e) => this.handleSubjectChange(e.target));
        document.getElementById('flow-custom-subject').addEventListener('input', (e) => this.handleCustomSubjectInput(e.target));
        document.getElementById('flow-session-notes').addEventListener('input', (e) => {
            AppState.flowState.notes = e.target.value.trim();
            this.validateDetails();
        });
    },

    /**
     * Handle subject selection change
     * @param {HTMLSelectElement} select - Subject select element
     */
    handleSubjectChange(select) {
        const customContainer = document.getElementById('flow-custom-subject-container');
        const customError = document.getElementById('flow-custom-subject-error');

        if (select.value === 'other') {
            customContainer.classList.add('active');
        } else {
            customContainer.classList.remove('active');
            customError.textContent = '';
            AppState.flowState.selectedSubject = select.value;
            document.getElementById('flow-selected-subject').textContent = select.value;
            this.validateDetails();
        }
    },

    /**
     * Handle custom subject input
     * @param {HTMLInputElement} input - Custom subject input
     */
    handleCustomSubjectInput(input) {
        const customError = document.getElementById('flow-custom-subject-error');

        if (input.value.trim() === '') {
            customError.textContent = 'Please specify your subject';
            AppState.flowState.selectedSubject = null;
            document.getElementById('flow-selected-subject').textContent = '';
        } else {
            customError.textContent = '';
            AppState.flowState.selectedSubject = input.value.trim();
            document.getElementById('flow-selected-subject').textContent = input.value.trim();
        }
        this.validateDetails();
    },

    /**
     * Validate details step
     */
    validateDetails() {
        let valid = true;

        if (!AppState.flowState.selectedSubject) {
            Utils.showError('details-error', 'Please select or specify a subject.');
            valid = false;
        } else {
            Utils.clearError('details-error');
        }

        document.getElementById('details-next-btn').disabled = !valid;
    },

    // ============ STEP 4: CONFIRMATION ============

    /**
     * Load confirmation step
     */
    loadConfirmation() {
        if (!AppState.flowState.selectedSubject || !AppState.flowState.selectedDate || !AppState.flowState.selectedTime) {
            Utils.showError('confirm-error', 'Please complete all previous steps.');
            document.getElementById('confirm-submit-btn').disabled = true;
            return;
        }

        const tutor = Tutors.getById(AppState.flowState.selectedTutorId);
        if (!tutor) return;

        document.getElementById('confirm-tutor-flow').textContent = tutor.name;
        document.getElementById('confirm-subject-flow').textContent = AppState.flowState.selectedSubject;
        document.getElementById('confirm-date-flow').textContent = Utils.formatDate(AppState.flowState.selectedDate);
        document.getElementById('confirm-time-flow').textContent = Utils.formatTime(AppState.flowState.selectedTime);
        document.getElementById('confirm-notes-flow').textContent = AppState.flowState.notes || '(No additional notes)';

        document.getElementById('confirm-submit-btn').disabled = false;
    },

    // ============ NAVIGATION ============

    /**
     * Go to next step
     * @param {number} currentStep - Current step number
     */
    nextStep(currentStep) {
        // Validate current step before proceeding
        if (currentStep === 1 && !AppState.flowState.selectedDate) {
            Utils.showError('date-error', 'Please select a date.');
            return;
        }
        if (currentStep === 2 && !AppState.flowState.selectedTime) {
            Utils.showError('time-error', 'Please select a time.');
            return;
        }
        if (currentStep === 3 && !AppState.flowState.selectedSubject) {
            Utils.showError('details-error', 'Please select or specify a subject.');
            return;
        }

        AppState.flowState.step = currentStep + 1;
        this.updateStepIndicator();
        this.showStep(currentStep + 1);
    },

    /**
     * Go to previous step
     * @param {number} currentStep - Current step number
     */
    prevStep(currentStep) {
        AppState.flowState.step = currentStep - 1;
        this.updateStepIndicator();
        this.showStep(currentStep - 1);
    },

    /**
     * Submit the session request
     */
    submitRequest() {
        if (!AppState.flowState.selectedSubject || !AppState.flowState.selectedDate || !AppState.flowState.selectedTime) {
            Utils.showError('confirm-error', 'Please complete all steps.');
            return;
        }

        const tutor = Tutors.getById(AppState.flowState.selectedTutorId);
        if (!tutor) return;

        // Create request object
        const request = {
            tutor: tutor.name,
            student: AppState.currentUser.name,
            subject: AppState.flowState.selectedSubject,
            date: AppState.flowState.selectedDate,
            time: AppState.flowState.selectedTime,
            notes: AppState.flowState.notes,
            timestamp: Utils.formatTimestamp(new Date()),
            status: 'Pending',
            cancellationReason: '',
            declineReason: ''
        };

        AppState.addRequest(request);

        // Show confirmation screen with request details
        document.getElementById('confirm-tutor').textContent = request.tutor;
        document.getElementById('confirm-subject').textContent = request.subject;
        document.getElementById('confirm-date').textContent = Utils.formatDate(request.date);
        document.getElementById('confirm-time').textContent = Utils.formatTime(request.time);

        // Reset flow state
        AppState.resetFlow();

        // Navigate to confirmation screen
        Navigation.showScreen('confirmation-screen');
    },

    /**
     * Bind navigation events
     */
    bindEvents() {
        // Step 1: Date -> Time
        const dateNextBtn = document.getElementById('date-next-btn');
        if (dateNextBtn) {
            dateNextBtn.addEventListener('click', () => this.nextStep(1));
        }

        // Step 2: Time -> Date (back) / Details (next)
        const timeBackBtn = document.getElementById('time-back-btn');
        if (timeBackBtn) {
            timeBackBtn.addEventListener('click', () => this.prevStep(2));
        }
        const timeNextBtn = document.getElementById('time-next-btn');
        if (timeNextBtn) {
            timeNextBtn.addEventListener('click', () => this.nextStep(2));
        }

        // Step 3: Details -> Time (back) / Confirm (next)
        const detailsBackBtn = document.getElementById('details-back-btn');
        if (detailsBackBtn) {
            detailsBackBtn.addEventListener('click', () => this.prevStep(3));
        }
        const detailsNextBtn = document.getElementById('details-next-btn');
        if (detailsNextBtn) {
            detailsNextBtn.addEventListener('click', () => this.nextStep(3));
        }

        // Step 4: Confirm -> Details (back) / Submit
        const confirmBackBtn = document.getElementById('confirm-back-btn');
        if (confirmBackBtn) {
            confirmBackBtn.addEventListener('click', () => this.prevStep(4));
        }
        const confirmSubmitBtn = document.getElementById('confirm-submit-btn');
        if (confirmSubmitBtn) {
            confirmSubmitBtn.addEventListener('click', () => this.submitRequest());
        }

        // Back to profile button
        const backToProfileBtn = document.getElementById('back-to-profile-from-flow');
        if (backToProfileBtn) {
            backToProfileBtn.addEventListener('click', () => {
                Navigation.showScreen('tutor-profile-screen');
            });
        }
    }
};

// Auto-initialize when request flow screen is shown
document.addEventListener('screen:show', (e) => {
    if (e.detail.screenId === 'request-session-flow-screen') {
        RequestFlowPage.bindEvents();
        // If flow already initialized, show current step
        if (AppState.flowState.selectedTutorId) {
            RequestFlowPage.updateStepIndicator();
            RequestFlowPage.showStep(AppState.flowState.step);
        }
    }
});

// Export
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { RequestFlowPage };
}
window.RequestFlowPage = RequestFlowPage;