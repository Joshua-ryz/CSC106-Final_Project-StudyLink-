/**
 * StudyLink - Tutor Search Page Logic
 */

const SearchPage = {
    /**
     * Initialize search page
     */
    init() {
        this.bindEvents();
    },

    /**
     * Bind event listeners
     */
    bindEvents() {
        // Back to dashboard button
        const backBtn = document.getElementById('back-to-dashboard-from-search');
        if (backBtn) {
            backBtn.addEventListener('click', () => {
                Navigation.showScreen('dashboard-screen');
            });
        }

        // Search form submission
        const searchForm = document.getElementById('tutor-search-form');
        if (searchForm) {
            searchForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.performSearch();
            });
        }

        // Search button
        const searchBtn = document.getElementById('search-tutors-btn');
        if (searchBtn) {
            searchBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.performSearch();
            });
        }
    },

    /**
     * Perform search and navigate to results
     */
    performSearch() {
        AppState.searchState.isShowingFilteredResults = true;
        AppState.searchState.lastFilters = this.getFilters();
        SearchResultsPage.displayResults();
        Navigation.showScreen('search-results-screen');
    },

    /**
     * Get current filter values from form
     * @returns {Object} Filter object
     */
    getFilters() {
        return {
            subject: document.getElementById('search-subject').value,
            expertise: document.getElementById('filter-expertise').value,
            availability: document.getElementById('filter-availability').value,
            rating: document.getElementById('filter-rating').value
        };
    }
};

// Auto-initialize when search screen is shown
document.addEventListener('screen:show', (e) => {
    if (e.detail.screenId === 'tutor-search-screen') {
        SearchPage.init();
    }
});

// Export
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { SearchPage };
}
window.SearchPage = SearchPage;