/**
 * StudyLink - Shared Application State
 * Central state management for the application
 */

const AppState = {
    // Navigation history for back button functionality
    navigationHistory: [],

    // Current user data
    currentUser: {
        email: '',
        name: '',
        isLoggedIn: false
    },

    // Current tutor being viewed
    currentTutor: null,

    // Form values cache
    formValues: {},

    // Submitted tutoring requests
    submittedRequests: [],

    // Request flow state (multi-step session request)
    flowState: {
        step: 1, // 1: date, 2: time, 3: details, 4: confirm
        selectedTutorId: null,
        selectedSubject: null,
        selectedDate: null, // YYYY-MM-DD
        selectedTime: null, // HH:mm
        notes: ''
    },

    // Search/filter state
    searchState: {
        isShowingFilteredResults: false,
        lastFilters: {}
    },

    // Initialize state from localStorage if available
    init() {
        this.loadFromStorage();
    },

    // Save state to localStorage
    saveToStorage() {
        const data = {
            currentUser: this.currentUser,
            submittedRequests: this.submittedRequests,
            formValues: this.formValues
        };
        try {
            localStorage.setItem('studylink_state', JSON.stringify(data));
        } catch (e) {
            console.warn('Failed to save state to localStorage:', e);
        }
    },

    // Load state from localStorage
    loadFromStorage() {
        try {
            const data = JSON.parse(localStorage.getItem('studylink_state'));
            if (data) {
                this.currentUser = data.currentUser || this.currentUser;
                this.submittedRequests = data.submittedRequests || [];
                this.formValues = data.formValues || {};
            }
        } catch (e) {
            console.warn('Failed to load state from localStorage:', e);
        }
    },

    // User authentication methods
    login(email) {
        this.currentUser.email = email;
        this.currentUser.name = email.split('@')[0] || 'Student';
        this.currentUser.isLoggedIn = true;
        this.saveToStorage();
    },

    logout() {
        this.currentUser = {
            email: '',
            name: '',
            isLoggedIn: false
        };
        this.currentTutor = null;
        this.formValues = {};
        this.navigationHistory = [];
        this.saveToStorage();
    },

    // Navigation methods
    pushHistory(screenId) {
        if (!['login-screen', 'register-screen'].includes(screenId)) {
            this.navigationHistory.push(screenId);
        }
    },

    popHistory() {
        if (this.navigationHistory.length > 0) {
            this.navigationHistory.pop(); // Remove current
            return this.navigationHistory.pop() || 'dashboard-screen'; // Return previous
        }
        return 'login-screen';
    },

    clearHistory() {
        this.navigationHistory = [];
    },

    // Request flow methods
    initFlow(tutorId) {
        this.flowState = {
            step: 1,
            selectedTutorId: tutorId,
            selectedSubject: null,
            selectedDate: null,
            selectedTime: null,
            notes: ''
        };
    },

    resetFlow() {
        this.flowState = {
            step: 1,
            selectedTutorId: null,
            selectedSubject: null,
            selectedDate: null,
            selectedTime: null,
            notes: ''
        };
    },

    // Request management
    addRequest(request) {
        this.submittedRequests.push(request);
        this.saveToStorage();
    },

    updateRequest(index, updates) {
        if (this.submittedRequests[index]) {
            this.submittedRequests[index] = {
                ...this.submittedRequests[index],
                ...updates
            };
            this.saveToStorage();
        }
    },

    getRequests() {
        return this.submittedRequests;
    }
};

// Export for module usage
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { AppState };
}

// Make available globally for non-module usage
window.AppState = AppState;