/**
 * StudyLink - Tutor Data Module
 * Handles tutor data access and filtering logic
 */

const Tutors = {
    // Tutor data (will be loaded from data/tutors.js)
    data: {},

    /**
     * Initialize tutor data
     * @param {Object} tutorData - Tutor data object
     */
    init(tutorData) {
        this.data = tutorData;
    },

    /**
     * Get all tutors as array
     * @returns {Object[]} Array of tutor objects
     */
    getAll() {
        return Object.values(this.data);
    },

    /**
     * Get tutor by ID
     * @param {string} id - Tutor ID
     * @returns {Object|null} Tutor object or null
     */
    getById(id) {
        return this.data[id] || null;
    },

    /**
     * Filter tutors based on search criteria
     * @param {Object} filters - Filter criteria
     * @returns {Object[]} Filtered tutors
     */
    filter(filters) {
        const { subject, expertise, availability, rating } = filters;
        const tutorArray = this.getAll();

        return tutorArray.filter(tutor => {
            // Subject filter
            let subjectMatch = true;
            if (subject && subject !== '') {
                if (subject === 'Other') {
                    // For "Other", show tutors with subjects not in the standard list
                    const standardSubjects = [
                        'Mathematics', 'Programming', 'Java Programming',
                        'Data Structures and Algorithms', 'Software Engineering',
                        'Physics', 'English'
                    ];
                    subjectMatch = !standardSubjects.some(s => tutor.subjects.includes(s));
                } else {
                    subjectMatch = tutor.subjects.includes(subject);
                }
            }
            if (!subjectMatch) return false;

            // Expertise filter
            if (expertise && expertise !== '') {
                if (tutor.expertise.toLowerCase().indexOf(expertise.toLowerCase()) === -1) {
                    return false;
                }
            }

            // Availability filter
            if (availability && availability !== '') {
                let preferredStartMin = 0;
                let preferredEndMin = 24 * 60;

                if (availability === 'morning') {
                    preferredStartMin = 8 * 60;
                    preferredEndMin = 12 * 60;
                } else if (availability === 'afternoon') {
                    preferredStartMin = 13 * 60;
                    preferredEndMin = 17 * 60;
                } else if (availability === 'evening') {
                    preferredStartMin = 18 * 60;
                    preferredEndMin = 21 * 60;
                }

                // Check if tutor has ANY overlap with preferred time on ANY available day
                let hasOverlap = false;
                for (const dayIndex of tutor.availabilityDays) {
                    const tutorStart = tutor.availabilityStart;
                    const tutorEnd = tutor.availabilityEnd;

                    if (tutorStart < preferredEndMin && preferredStartMin < tutorEnd) {
                        hasOverlap = true;
                        break;
                    }
                }

                if (!hasOverlap) return false;
            }

            // Rating filter
            if (rating && rating !== '') {
                if (tutor.rating < parseFloat(rating)) {
                    return false;
                }
            }

            return true;
        });
    },

    /**
     * Get available dates for a tutor
     * @param {string} tutorId - Tutor ID
     * @returns {string[]} Array of date strings
     */
    getAvailableDates(tutorId) {
        const tutor = this.getById(tutorId);
        if (!tutor) return [];
        return Utils.getAvailableDates(tutor);
    },

    /**
     * Get time slots for a tutor on a specific date
     * @param {string} tutorId - Tutor ID
     * @param {string} dateStr - Date in YYYY-MM-DD format
     * @returns {Object[]} Array of time slot objects
     */
    getTimeSlots(tutorId, dateStr) {
        const tutor = this.getById(tutorId);
        if (!tutor) return [];
        return Utils.getTimeSlots(tutor, dateStr);
    }
};

// Export for module usage
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { Tutors };
}

// Make available globally
window.Tutors = Tutors;