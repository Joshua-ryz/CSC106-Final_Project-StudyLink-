/**
 * StudyLink - Utility Functions
 * Common helper functions used across the application
 */

const Utils = {
    /**
     * Format date string (YYYY-MM-DD) to readable format
     * @param {string} dateStr - Date in YYYY-MM-DD format
     * @returns {string} Formatted date string
     */
    formatDate(dateStr) {
        if (!dateStr) return '';
        const options = { weekday: 'short', year: 'numeric', month: 'short', day: 'numeric' };
        return new Date(dateStr).toLocaleDateString(undefined, options);
    },

    /**
     * Format time string (HH:mm) to 12-hour format with AM/PM
     * @param {string} timeStr - Time in HH:mm format
     * @returns {string} Formatted time string
     */
    formatTime(timeStr) {
        if (!timeStr) return '';
        const [hours, minutes] = timeStr.split(':');
        const hour = parseInt(hours, 10);
        const ampm = hour >= 12 ? 'PM' : 'AM';
        const hour12 = hour % 12 || 12;
        return `${hour12}:${minutes} ${ampm}`;
    },

    /**
     * Get available dates for a tutor within the next 14 days
     * @param {Object} tutor - Tutor object with availabilityDays
     * @returns {string[]} Array of date strings in YYYY-MM-DD format
     */
    getAvailableDates(tutor) {
        const today = new Date();
        const dates = [];
        for (let i = 0; i < 14; i++) {
            const date = new Date(today);
            date.setDate(today.getDate() + i);
            const day = date.getDay(); // 0 Sunday, 1 Monday, etc.
            if (tutor.availabilityDays.includes(day)) {
                dates.push(date.toISOString().split('T')[0]);
            }
        }
        return dates;
    },

    /**
     * Get time slots for a tutor on a specific date
     * @param {Object} tutor - Tutor object with availabilityStart/End
     * @param {string} dateStr - Date in YYYY-MM-DD format
     * @returns {Object[]} Array of time slot objects
     */
    getTimeSlots(tutor, dateStr) {
        const slots = [];
        const start = tutor.availabilityStart;
        const end = tutor.availabilityEnd;
        const slotDuration = 30; // 30-minute slots

        for (let time = start; time < end; time += slotDuration) {
            const hours = Math.floor(time / 60);
            const minutes = time % 60;
            const timeString = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;

            // For demo: mark first two slots as booked, rest available
            const isBooked = slots.length < 2;
            slots.push({
                time: timeString,
                available: true,
                booked: isBooked
            });
        }
        return slots;
    },

    /**
     * Generate star rating display
     * @param {number} rating - Rating value (e.g., 4.5)
     * @returns {string} HTML string with stars
     */
    generateStars(rating) {
        const fullStars = Math.floor(rating);
        const hasHalfStar = rating % 1 !== 0;
        return '★'.repeat(fullStars) + (hasHalfStar ? '☆' : '');
    },

    /**
     * Escape HTML to prevent XSS
     * @param {string} str - String to escape
     * @returns {string} Escaped string
     */
    escapeHtml(str) {
        if (!str) return '';
        const div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    },

    /**
     * Create element with attributes and content
     * @param {string} tag - HTML tag name
     * @param {Object} attributes - Attributes to set
     * @param {string|HTMLElement} content - Inner content
     * @returns {HTMLElement} Created element
     */
    createElement(tag, attributes = {}, content = '') {
        const el = document.createElement(tag);
        Object.entries(attributes).forEach(([key, value]) => {
            if (key === 'class') {
                el.className = value;
            } else if (key === 'dataset') {
                Object.entries(value).forEach(([dataKey, dataValue]) => {
                    el.dataset[dataKey] = dataValue;
                });
            } else if (key.startsWith('on') && typeof value === 'function') {
                el.addEventListener(key.slice(2).toLowerCase(), value);
            } else {
                el.setAttribute(key, value);
            }
        });
        if (typeof content === 'string') {
            el.innerHTML = content;
        } else if (content instanceof HTMLElement) {
            el.appendChild(content);
        }
        return el;
    },

    /**
     * Show error message in an error element
     * @param {string} elementId - ID of error message element
     * @param {string} message - Error message
     */
    showError(elementId, message) {
        const el = document.getElementById(elementId);
        if (el) {
            el.textContent = message;
        }
    },

    /**
     * Clear error message
     * @param {string} elementId - ID of error message element
     */
    clearError(elementId) {
        const el = document.getElementById(elementId);
        if (el) {
            el.textContent = '';
        }
    },

    /**
     * Validate email format (basic)
     * @param {string} email - Email to validate
     * @returns {boolean} True if valid
     */
    validateEmail(email) {
        return email && email.includes('@') && email.includes('.');
    },

    /**
     * Debounce function
     * @param {Function} func - Function to debounce
     * @param {number} wait - Wait time in ms
     * @returns {Function} Debounced function
     */
    debounce(func, wait) {
        let timeout;
        return function(...args) {
            clearTimeout(timeout);
            timeout = setTimeout(() => func.apply(this, args), wait);
        };
    },

    /**
     * Format timestamp for display
     * @param {Date|string} date - Date object or string
     * @returns {string} Formatted timestamp
     */
    formatTimestamp(date) {
        const d = new Date(date);
        return d.toLocaleString();
    }
};

// Export for module usage
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { Utils };
}

// Make available globally
window.Utils = Utils;